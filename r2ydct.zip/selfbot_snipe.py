#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
DISCORD SELFBOT SNIPE & AUTO-MUTE TRIGGER (PYTHON VERSION)
==============================================================================
Tính năng:
1. Theo dõi từ khóa (mặc định: "alo")
2. Khi user chat từ đó 10 lần -> Tự động gửi lệnh: ?to <user> 15m spam trigger bot
3. Lệnh .snipe <từ>: Cài đặt từ khóa muốn snipe/trigger
4. Lệnh .snipe (không từ): Xem tin nhắn bị xóa gần nhất trong kênh
5. Lệnh .stats, .snipelimit, .snipetime, .snipereason, .whitelist, .help
==============================================================================
"""

import os
import sys
import json
import time
import socket
import ssl
import threading
import urllib.request
import urllib.error
import urllib.parse
from datetime import datetime

# ==================== ANSI COLORS ====================
class C:
    RESET = "\033[0m"
    BRIGHT = "\033[1m"
    DIM = "\033[2m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"
    BG_RED = "\033[41m"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

custom_config = None
for i, arg in enumerate(sys.argv):
    if arg == "--config" and i + 1 < len(sys.argv):
        custom_config = sys.argv[i + 1]
        break
if not custom_config:
    custom_config = os.environ.get("CONFIG_FILE")

CONFIG_FILE = os.path.join(BASE_DIR, custom_config) if custom_config else os.path.join(BASE_DIR, "config_snipe.json")

DEFAULT_CONFIG = {
    "token": "",
    "prefix": ".",
    "triggerWord": "alo",
    "triggerLimit": 10,
    "muteDuration": "15m",
    "muteReason": "spam trigger bot",
    "muteCommandFormat": "?to <user> <duration> <reason>",
    "mentionInMute": True,
    "matchMode": "contains",
    "autoDeleteCommand": False,
    "autoDeleteDelayMs": 3000,
    "autoResetMinutes": 30,
    "enabled": True,
    "whitelist": [],
    "blacklistedChannels": [],
    "whitelistedChannels": []
}

def load_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                cfg = json.load(f)
                return {**DEFAULT_CONFIG, **cfg}
        except Exception as e:
            print(f"{C.RED}[ERROR] Lỗi đọc config: {e}{C.RESET}")
    return DEFAULT_CONFIG.copy()

def save_config(cfg):
    try:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"{C.RED}[ERROR] Lỗi lưu config: {e}{C.RESET}")

# ==================== DISCORD REST API ====================
def discord_api(endpoint, token, method="GET", data=None):
    url = f"https://discord.com/api/v9{endpoint}"
    req = urllib.request.Request(url, method=method)
    req.add_header("Authorization", token)
    req.add_header("Content-Type", "application/json")
    req.add_header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9175 Chrome/128.0.6613.186 Electron/32.2.7 Safari/537.36")
    
    body = json.dumps(data).encode("utf-8") if data else None
    try:
        with urllib.request.urlopen(req, data=body, timeout=15) as res:
            res_body = res.read().decode("utf-8")
            return json.loads(res_body) if res_body else {}
    except urllib.error.HTTPError as e:
        err_msg = e.read().decode("utf-8")
        try:
            err_json = json.loads(err_msg)
            return {"error": True, "status": e.code, "message": err_json.get("message", err_msg)}
        except:
            return {"error": True, "status": e.code, "message": err_msg}
    except Exception as e:
        return {"error": True, "message": str(e)}

def send_message(channel_id, content, token):
    return discord_api(f"/channels/{channel_id}/messages", token, method="POST", data={
        "content": content,
        "flags": 0,
        "tts": False
    })

def delete_message(channel_id, message_id, token):
    return discord_api(f"/channels/{channel_id}/messages/{message_id}", token, method="DELETE")

# ==================== LIGHTWEIGHT WEBSOCKET CLIENT ====================
import base64
import struct

class SimpleWebSocketClient:
    def __init__(self, host, path, port=443, headers=None):
        self.host = host
        self.path = path
        self.port = port
        self.headers = headers or {}
        self.sock = None
        self.connected = False
        self.lock = threading.Lock()

    def connect(self):
        raw_sock = socket.create_connection((self.host, self.port), timeout=15)
        ctx = ssl.create_default_context()
        self.sock = ctx.wrap_socket(raw_sock, server_hostname=self.host)
        
        # Handshake
        key = base64.b64encode(os.urandom(16)).decode("utf-8")
        req_lines = [
            f"GET {self.path} HTTP/1.1",
            f"Host: {self.host}",
            "Upgrade: websocket",
            "Connection: Upgrade",
            f"Sec-WebSocket-Key: {key}",
            "Sec-WebSocket-Version: 13"
        ]
        for k, v in self.headers.items():
            req_lines.append(f"{k}: {v}")
        req_lines.append("\r\n")

        self.sock.sendall("\r\n".join(req_lines).encode("utf-8"))
        
        # Read HTTP response headers
        resp = b""
        while b"\r\n\r\n" not in resp:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise Exception("WebSocket handshake failed (empty response)")
            resp += chunk
        
        status_line = resp.split(b"\r\n")[0].decode("utf-8")
        if "101" not in status_line:
            raise Exception(f"WebSocket handshake failed: {status_line}")
        
        self.connected = True

    def send_text(self, text):
        if not self.connected or not self.sock:
            return
        payload = text.encode("utf-8")
        length = len(payload)
        mask_key = os.urandom(4)
        
        # Opcode 1 = text frame, fin = 1, mask = 1
        header = bytearray()
        header.append(0x81)
        
        if length <= 125:
            header.append(0x80 | length)
        elif length <= 65535:
            header.append(0x80 | 126)
            header.extend(struct.pack("!H", length))
        else:
            header.append(0x80 | 127)
            header.extend(struct.pack("!Q", length))
            
        header.extend(mask_key)
        
        # Mask payload
        masked_payload = bytearray(payload)
        for i in range(len(masked_payload)):
            masked_payload[i] ^= mask_key[i % 4]
            
        with self.lock:
            try:
                self.sock.sendall(header + masked_payload)
            except Exception as e:
                self.connected = False

    def recv_frame(self):
        if not self.connected or not self.sock:
            return None
        
        def read_exact(n):
            buf = bytearray()
            while len(buf) < n:
                chunk = self.sock.recv(n - len(buf))
                if not chunk:
                    raise EOFError("Socket closed")
                buf.extend(chunk)
            return bytes(buf)

        try:
            head = read_exact(2)
            b1, b2 = head[0], head[1]
            opcode = b1 & 0x0F
            is_masked = (b2 & 0x80) != 0
            payload_len = b2 & 0x7F

            if payload_len == 126:
                payload_len = struct.unpack("!H", read_exact(2))[0]
            elif payload_len == 127:
                payload_len = struct.unpack("!Q", read_exact(8))[0]

            mask = read_exact(4) if is_masked else None
            data = read_exact(payload_len)

            if is_masked and mask:
                unmasked = bytearray(data)
                for i in range(len(unmasked)):
                    unmasked[i] ^= mask[i % 4]
                data = bytes(unmasked)

            # Text frame (0x1) or Ping (0x9) or Close (0x8)
            if opcode == 0x1:
                return {"type": "text", "data": data.decode("utf-8", errors="ignore")}
            elif opcode == 0x9:
                # Pong response
                pong_header = bytearray([0x8A, 0x80]) + os.urandom(4)
                with self.lock:
                    self.sock.sendall(pong_header)
                return {"type": "ping"}
            elif opcode == 0x8:
                self.connected = False
                return {"type": "close"}
            return {"type": "other"}
        except Exception:
            self.connected = False
            return None

    def close(self):
        self.connected = False
        if self.sock:
            try:
                self.sock.close()
            except:
                pass

# ==================== MAIN SELFBOT CLASS ====================
class DiscordSnipeSelfbot:
    def __init__(self):
        self.config = load_config()
        self.current_user = None
        self.spam_tracker = {}  # {user_id: {"count": int, "last_time": float, "username": str, "channel_id": str}}
        self.deleted_messages = {} # {channel_id: list}
        self.edited_messages = {} # {channel_id: list}
        self.message_cache = {} # {msg_id: dict}
        self.ws_client = None
        self.last_seq = None
        self.session_id = None
        self.heartbeat_timer = None
        self.running = True

    def print_banner(self):
        print(f"{C.MAGENTA}{C.BRIGHT}")
        print("  ███████╗███╗   ██╗██╗██████╗ ███████╗    ██████╗  ██████╗ ████████╗")
        print("  ██╔════╝████╗  ██║██║██╔══██╗██╔════╝    ██╔══██╗██╔═══██╗╚══██╔══╝")
        print("  ███████╗██╔██╗ ██║██║██████╔╝█████╗      ██████╔╝██║   ██║   ██║   ")
        print("  ╚════██║██║╚██╗██║██║██╔═══╝ ██╔══╝      ██╔══██╗██║   ██║   ██║   ")
        print("  ███████║██║ ╚████║██║██║     ███████╗    ██████╔╝╚██████╔╝   ██║   ")
        print("  ╚══════╝╚═╝  ╚═══╝╚═╝╚═╝     ╚══════╝    ╚═════╝  ╚═════╝    ╚═╝   ")
        print(f"{C.CYAN}            Auto ?to 15p When Chat '{self.config['triggerWord']}' 10 Times (Python Edition){C.RESET}\n")

    def start_heartbeat(self, interval_ms):
        def heartbeat_loop():
            while self.running and self.ws_client and self.ws_client.connected:
                hb = {"op": 1, "d": self.last_seq}
                self.ws_client.send_text(json.dumps(hb))
                time.sleep(interval_ms / 1000.0)
        
        t = threading.Thread(target=heartbeat_loop, daemon=True)
        t.start()

    def handle_message(self, msg):
        author = msg.get("author")
        if not author:
            return

        author_id = author.get("id")
        username = author.get("username", "Unknown")
        discriminator = author.get("discriminator", "0")
        author_tag = f"{username}#{discriminator}"
        channel_id = msg.get("channel_id")
        content = (msg.get("content") or "").strip()
        is_self = self.current_user and author_id == self.current_user.get("id")

        # 1. XỬ LÝ LỆNH TỪ CHỦ BOT (Prefix: .)
        if is_self and content.startswith(self.config["prefix"]):
            parts = content[len(self.config["prefix"]):].strip().split()
            if parts:
                cmd = parts[0].lower()
                args = parts[1:]
                self.handle_self_command(cmd, args, msg)
            return

        # Nếu tắt hoặc là bot tự nhắn -> bỏ qua
        if not self.config["enabled"] or is_self:
            return

        # Kiểm tra whitelist / blacklist
        if author_id in self.config["whitelist"]:
            return
        if channel_id in self.config["blacklistedChannels"]:
            return
        if self.config["whitelistedChannels"] and channel_id not in self.config["whitelistedChannels"]:
            return

        # 2. KIỂM TRA TỪ KHÓA ĐỂ AUTO ?TO
        trigger = (self.config["triggerWord"] or "").strip().lower()
        if not trigger:
            return

        msg_lower = content.lower()
        matched = False
        if self.config["matchMode"] == "exact":
            matched = msg_lower == trigger
        else:
            matched = trigger in msg_lower

        if matched:
            now = time.time()
            stats = self.spam_tracker.get(author_id)

            # Auto decay / reset sau X phút
            if stats and (now - stats["last_time"]) > (self.config["autoResetMinutes"] * 60):
                stats["count"] = 0

            if not stats:
                stats = {"count": 0, "last_time": now, "username": author_tag, "channel_id": channel_id}
                self.spam_tracker[author_id] = stats

            stats["count"] += 1
            stats["last_time"] = now
            stats["username"] = author_tag
            stats["channel_id"] = channel_id

            print(
                f"{C.YELLOW}[TRIGGER]{C.RESET} 👤 {C.GREEN}{author_tag}{C.RESET} (ID: {C.DIM}{author_id}{C.RESET}) "
                f"chat: \"{C.MAGENTA}{content}{C.RESET}\" | {C.BRIGHT}{C.YELLOW}Lần: {stats['count']}/{self.config['triggerLimit']}{C.RESET}"
            )

            # ĐẠT ĐỦ 10 LẦN
            if stats["count"] >= self.config["triggerLimit"]:
                stats["count"] = 0 # Reset
                
                target = f"<@{author_id}>" if self.config["mentionInMute"] else author_id
                mute_cmd = self.config["muteCommandFormat"]\
                    .replace("<user>", target)\
                    .replace("<duration>", self.config["muteDuration"])\
                    .replace("<reason>", self.config["muteReason"])

                print(
                    f"\n{C.BG_RED}{C.WHITE}{C.BRIGHT} [AUTO-MUTE ACTION] {C.RESET} "
                    f"User {C.GREEN}{author_tag}{C.RESET} chat \"{C.MAGENTA}{self.config['triggerWord']}{C.RESET}\" "
                    f"đạt {C.RED}{self.config['triggerLimit']} lần!{C.RESET}"
                )
                print(f"{C.YELLOW}➔ Đang gửi lệnh: {C.BRIGHT}{mute_cmd}{C.RESET} vào kênh {channel_id}\n")

                # Gửi lệnh ?to
                send_message(channel_id, mute_cmd, self.config["token"])

    def handle_self_command(self, cmd, args, msg):
        channel_id = msg.get("channel_id")
        msg_id = msg.get("id")

        # Lệnh: .snipe [từ]
        if cmd == "snipe":
            if args:
                new_word = " ".join(args).strip()
                self.config["triggerWord"] = new_word
                save_config(self.config)
                rep = (
                    f"🎯 **[SNIPE CONFIG]** Đã đặt từ khóa theo dõi thành: `{new_word}`\n"
                    f"⚡ Khi ai chat từ này **{self.config['triggerLimit']} lần** sẽ tự động: "
                    f"`?to <user> {self.config['muteDuration']} {self.config['muteReason']}`"
                )
                send_message(channel_id, rep, self.config["token"])
                print(f"{C.GREEN}[CONFIG] Đã cập nhật từ khóa Snipe: '{new_word}'{C.RESET}")
                return

            # Snipe tin nhắn bị xóa
            list_deleted = self.deleted_messages.get(channel_id, [])
            if not list_deleted:
                send_message(channel_id, "❌ Không có tin nhắn nào bị xóa gần đây trong kênh này!", self.config["token"])
                return

            last = list_deleted[0]
            author = last.get("author", {})
            author_tag = f"{author.get('username', 'Ẩn danh')}#{author.get('discriminator', '0')}"
            deleted_time = last.get("deletedAt", "")

            rep = (
                f"🕵️‍♂️ **[SNIPED DELETED MESSAGE]**\n"
                f"👤 **Người gửi:** `{author_tag}` (<@{author.get('id', '')}>)\n"
                f"🕒 **Thời gian:** `{deleted_time}`\n"
                f"💬 **Nội dung:**\n>>> {last.get('content') or '*(Không có chữ / File)*'}"
            )
            send_message(channel_id, rep, self.config["token"])
            return

        # Lệnh: .stats
        if cmd in ["stats", "snipestats"]:
            if not self.spam_tracker:
                send_message(channel_id, f"📊 Chưa có ai bị ghi nhận chat `{self.config['triggerWord']}`.", self.config["token"])
                return

            rep = f"📊 **[THEO DÕI SPAM: \"{self.config['triggerWord']}\"]** (Mute: {self.config['triggerLimit']} lần / {self.config['muteDuration']})\n\n"
            idx = 1
            for uid, data in self.spam_tracker.items():
                if data["count"] > 0:
                    rep += f"**{idx}.** `{data['username']}` (<@{uid}>): **{data['count']}/{self.config['triggerLimit']} lần**\n"
                    idx += 1
            if idx == 1:
                rep += "*(Hiện chưa có user nào tích lũy lần chat)*"
            send_message(channel_id, rep, self.config["token"])
            return

        # Lệnh: .snipelimit
        if cmd == "snipelimit" and args:
            try:
                lim = int(args[0])
                if lim > 0:
                    self.config["triggerLimit"] = lim
                    save_config(self.config)
                    send_message(channel_id, f"✅ Đã đổi số lần trigger thành: **{lim} lần**.", self.config["token"])
                    return
            except:
                pass
            send_message(channel_id, "❌ Vui lòng nhập số hợp lệ. Ví dụ: `.snipelimit 10`", self.config["token"])
            return

        # Lệnh: .snipetime
        if cmd == "snipetime" and args:
            dur = args[0]
            self.config["muteDuration"] = dur
            save_config(self.config)
            send_message(channel_id, f"✅ Đã đổi thời gian mute thành: **{dur}**.", self.config["token"])
            return

        # Lệnh: .snipereason
        if cmd == "snipereason" and args:
            reason = " ".join(args)
            self.config["muteReason"] = reason
            save_config(self.config)
            send_message(channel_id, f"✅ Đã đổi lý do mute thành: `{reason}`.", self.config["token"])
            return

        # Lệnh: .snipereset
        if cmd == "snipereset":
            if args:
                uid = args[0].replace("<", "").replace(">", "").replace("@", "").replace("!", "")
                if uid in self.spam_tracker:
                    del self.spam_tracker[uid]
                send_message(channel_id, f"✅ Đã reset bộ đếm cho user `{uid}`.", self.config["token"])
            else:
                self.spam_tracker.clear()
                send_message(channel_id, "✅ Đã reset toàn bộ bộ đếm spam!", self.config["token"])
            return

        # Lệnh: .snipeon / .snipeoff
        if cmd == "snipeon":
            self.config["enabled"] = True
            save_config(self.config)
            send_message(channel_id, f"✅ Đã **BẬT** auto ?to cho từ `{self.config['triggerWord']}`!", self.config["token"])
            return

        if cmd == "snipeoff":
            self.config["enabled"] = False
            save_config(self.config)
            send_message(channel_id, "⛔ Đã **TẮT** auto ?to!", self.config["token"])
            return

        # Lệnh: .whitelist
        if cmd == "whitelist":
            sub = args[0].lower() if args else "list"
            uid = args[1].replace("<", "").replace(">", "").replace("@", "").replace("!", "") if len(args) > 1 else None

            if sub == "add" and uid:
                if uid not in self.config["whitelist"]:
                    self.config["whitelist"].append(uid)
                    save_config(self.config)
                    send_message(channel_id, f"✅ Đã thêm `<@{uid}>` vào whitelist.", self.config["token"])
                else:
                    send_message(channel_id, "⚠️ User đã có trong whitelist!", self.config["token"])
                return

            if sub == "remove" and uid:
                self.config["whitelist"] = [x for x in self.config["whitelist"] if x != uid]
                save_config(self.config)
                send_message(channel_id, f"✅ Đã xóa `<@{uid}>` khỏi whitelist.", self.config["token"])
                return

            list_str = "\n".join([f"- <@{x}> (`{x}`)" for x in self.config["whitelist"]]) if self.config["whitelist"] else "*(Trống)*"
            send_message(channel_id, f"🛡️ **[WHITELIST MIỄN TRỪ]**\n{list_str}", self.config["token"])
            return

        # Lệnh: .help
        if cmd in ["help", "snipehelp"]:
            help_text = (
                f"📖 **=== SELFBOT SNIPE & AUTO-MUTE HELP ===**\n"
                f"`{self.config['prefix']}snipe <từ>` ➔ Đặt từ khóa theo dõi (Hiện tại: `{self.config['triggerWord']}`)\n"
                f"`{self.config['prefix']}snipe` ➔ Xem tin nhắn bị xóa gần nhất (Delete Snipe)\n"
                f"`{self.config['prefix']}stats` ➔ Xem danh sách người đang chat từ khóa và số lần\n"
                f"`{self.config['prefix']}snipelimit <số>` ➔ Đổi số lần chat để mute (Hiện tại: `{self.config['triggerLimit']}`)\n"
                f"`{self.config['prefix']}snipetime <time>` ➔ Đổi thời gian mute (Hiện tại: `{self.config['muteDuration']}`)\n"
                f"`{self.config['prefix']}snipereason <lý do>` ➔ Đổi lý do mute (Hiện tại: `{self.config['muteReason']}`)\n"
                f"`{self.config['prefix']}snipereset [id]` ➔ Reset bộ đếm 1 user hoặc tất cả\n"
                f"`{self.config['prefix']}snipeon` / `{self.config['prefix']}snipeoff` ➔ Bật / Tắt Auto Mute\n"
                f"`{self.config['prefix']}whitelist add/remove/list <id>` ➔ Quản lý người được miễn trừ\n\n"
                f"⚙️ **Cơ chế:** Ai chat `{self.config['triggerWord']}` đủ **{self.config['triggerLimit']} lần** "
                f"➔ Gửi: `?to <user> {self.config['muteDuration']} {self.config['muteReason']}`"
            )
            send_message(channel_id, help_text, self.config["token"])
            return

    def run(self):
        os.system("cls" if os.name == "nt" else "clear")
        self.print_banner()

        token = self.config.get("token", "").strip()
        if not token and os.path.exists(os.path.join(BASE_DIR, ".token")):
            try:
                with open(os.path.join(BASE_DIR, ".token"), "r") as f:
                    token = f.read().strip()
            except:
                pass

        if not token:
            token = input(f"{C.YELLOW}Nhập Discord User Token: {C.RESET}").strip()
            if not token:
                print(f"{C.RED}[LỖI] Token không được để trống!{C.RESET}")
                return
            self.config["token"] = token
            save_config(self.config)

        # Kiểm tra token
        print(f"{C.CYAN}Đang kiểm tra token...{C.RESET}")
        me = discord_api("/users/@me", token)
        if me.get("error"):
            print(f"{C.RED}[LỖI] Token không hợp lệ: {me.get('message')}{C.RESET}")
            return

        self.current_user = me
        print(f"{C.GREEN}✓ Đăng nhập thành công: {me.get('username')}#{me.get('discriminator', '0')} (ID: {me.get('id')}){C.RESET}\n")

        # Vòng lặp kết nối Gateway
        while self.running:
            try:
                print(f"{C.CYAN}[GATEWAY] Đang kết nối tới wss://gateway.discord.gg...{C.RESET}")
                headers = {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9175 Chrome/128.0.6613.186 Electron/32.2.7 Safari/537.36"
                }
                self.ws_client = SimpleWebSocketClient("gateway.discord.gg", "/?v=9&encoding=json", 443, headers)
                self.ws_client.connect()
                print(f"{C.GREEN}[GATEWAY] Kết nối thành công!{C.RESET}")

                while self.ws_client.connected:
                    frame = self.ws_client.recv_frame()
                    if not frame or frame.get("type") == "close":
                        break
                    if frame.get("type") == "text":
                        payload = json.loads(frame["data"])
                        op = payload.get("op")
                        d = payload.get("d")
                        s = payload.get("s")
                        t = payload.get("t")

                        if s is not None:
                            self.last_seq = s

                        if op == 10: # Hello
                            interval = d.get("heartbeat_interval", 41250)
                            self.start_heartbeat(interval)
                            
                            # Identify
                            identify_payload = {
                                "op": 2,
                                "d": {
                                    "token": token,
                                    "capabilities": 30717,
                                    "properties": {
                                        "os": "Windows",
                                        "browser": "Discord Client",
                                        "release_channel": "stable",
                                        "client_version": "1.0.9175",
                                        "os_version": "10.0.26100",
                                        "os_arch": "x64",
                                        "app_arch": "x64",
                                        "system_locale": "en-US",
                                        "browser_user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9175 Chrome/128.0.6613.186 Electron/32.2.7 Safari/537.36",
                                        "browser_version": "32.2.7",
                                        "client_build_number": 504649,
                                        "native_build_number": 59498,
                                        "client_event_source": None
                                    },
                                    "presence": {
                                        "status": "online",
                                        "since": 0,
                                        "activities": [],
                                        "afk": False
                                    },
                                    "compress": False
                                }
                            }
                            self.ws_client.send_text(json.dumps(identify_payload))

                        elif op == 0: # Dispatch
                            if t == "READY":
                                self.session_id = d.get("session_id")
                                print(f"{C.GREEN}{C.BRIGHT}=== SELFBOT ONLINE ==={C.RESET}")
                                print(f"{C.CYAN}• Theo dõi từ : {C.MAGENTA}{self.config['triggerWord']}{C.RESET}")
                                print(f"{C.CYAN}• Giới hạn    : {C.RED}{self.config['triggerLimit']} lần{C.RESET} -> {C.YELLOW}{self.config['muteDuration']}{C.RESET}")
                                print(f"{C.CYAN}• Prefix      : {C.YELLOW}{self.config['prefix']}{C.RESET}")
                                print(f"{C.YELLOW}Gõ {self.config['prefix']}help trong Discord để xem danh sách lệnh!{C.RESET}\n")

                            elif t == "MESSAGE_CREATE":
                                if d.get("id"):
                                    self.message_cache[d["id"]] = d
                                    if len(self.message_cache) > 1000:
                                        first_k = next(iter(self.message_cache))
                                        del self.message_cache[first_k]
                                self.handle_message(d)

                            elif t == "MESSAGE_DELETE":
                                ch_id = d.get("channel_id")
                                msg_id = d.get("id")
                                cached = self.message_cache.get(msg_id)
                                if cached and ch_id:
                                    if ch_id not in self.deleted_messages:
                                        self.deleted_messages[ch_id] = []
                                    cached_copy = cached.copy()
                                    cached_copy["deletedAt"] = datetime.now().strftime("%H:%M:%S")
                                    self.deleted_messages[ch_id].insert(0, cached_copy)
                                    if len(self.deleted_messages[ch_id]) > 20:
                                        self.deleted_messages[ch_id].pop()

            except Exception as e:
                print(f"{C.RED}[LỖI GATEWAY] {e}. Đang kết nối lại sau 3s...{C.RESET}")
            time.sleep(3)

if __name__ == "__main__":
    bot = DiscordSnipeSelfbot()
    try:
        bot.run()
    except KeyboardInterrupt:
        print(f"\n{C.YELLOW}Đã dừng bot.{C.RESET}")
        sys.exit(0)
