import requests
import re
import json
import random
import string
import time
import sys
import os
import threading
import queue

# Tối ưu unbuffered output cho Docker / Pterodactyl Console
try:
    sys.stdout.reconfigure(line_buffering=True)
    sys.stderr.reconfigure(line_buffering=True)
except Exception:
    pass

# Tự động nhận diện và nạp thư viện từ .local
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
for _p in [
    os.path.join(BASE_DIR, '.local', 'lib', 'python3.13', 'site-packages'),
    os.path.join(BASE_DIR, '.local', 'lib', 'site-packages'),
    BASE_DIR
]:
    if os.path.exists(_p) and _p not in sys.path:
        sys.path.insert(0, _p)

try:
    from fake_useragent import UserAgent
    ua = UserAgent()
    get_random_ua = lambda: ua.random
except Exception:
    USER_AGENTS = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:129.0) Gecko/20100101 Firefox/129.0",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
    ]
    get_random_ua = lambda: random.choice(USER_AGENTS)

# ==============================================================================
#                       CẤU HÌNH HỆ THỐNG / CONFIGURATION
# ==============================================================================
# Tài khoản đăng nhập Discord (Chủ Nhân Azure cung cấp)
DISCORD_EMAIL = "nguyenquan01203@gmail.com"
DISCORD_PASSWORD = "next_4083544f5431b2151eddc8404a1ba3600b"

# Token tài khoản Discord (Tự động cập nhật qua đăng nhập Email/Password hoặc file .discord_token)
DISCORD_TOKEN = "MTU0MjAyNTAzOTQyNjA5MzEwNw.Gd6xGN.u-sIQB0ZlfWOD8lYzifz-5mKYxHjGRGp2-iW1U"

# Cấu hình Host Pterodactyl Panel (HeavenCloud Server 86bdbdb9)
PTERO_URL = "https://control.heavencloud.in"
PTERO_SERVER_ID = "86bdbdb9"
PTERO_API_KEY = "ptlc_YOcv5m3rYoo4FZ0IKTGz7jF3Xbr8Kr9PMbIdOPozAe0"
AUTO_RESTART_HOST = False
IS_RUNNING_ON_HOST = os.path.exists("/home/container") or os.getcwd().startswith("/home/container")

# Discord Webhook URL nhận thông báo khi có username khả dụng / đổi tên thành công
WEBHOOK_URL = "https://discord.com/api/webhooks/1547577083125956729/F1OCPwzXRCIyCEXJvHZOP8-AcLUGimbVmkrylWm0Lc6iaEDZcE5VD8v7655jQyHOfUZc"

# Discord Webhook URL ghi nhận các username bị Taken (Chủ Nhân Azure chỉ định)
WEBHOOK_TAKEN_URL = "https://discord.com/api/webhooks/1547587395833040927/RgpGSwOMw4pgFKPTPvXw9l0MqWpKmP3JmyzgFRBe9ARj5stoo7ZFczqGIFOnoG1nFZCY"
ENABLE_TAKEN_WEBHOOK = True  # Cho phép gửi webhook báo các name đã bị Taken theo dạng gom nhóm (Batch)

# File lưu trữ danh sách username đã snipe thành công
SNIPED_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sniped_names.txt")
SNIPED_STATUS_MSG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".sniped_status_msg_id")

def load_sniped_status_msg_id():
    if os.path.exists(SNIPED_STATUS_MSG_FILE):
        try:
            with open(SNIPED_STATUS_MSG_FILE, "r", encoding="utf-8") as f:
                c = f.read().strip()
                if c.isdigit():
                    return c
        except Exception:
            pass
    return None

def save_sniped_status_msg_id(msg_id):
    if msg_id:
        try:
            with open(SNIPED_STATUS_MSG_FILE, "w", encoding="utf-8") as f:
                f.write(str(msg_id).strip())
        except Exception:
            pass


# Giới hạn tài nguyên phần cứng Host (Chủ Nhân Azure chỉ định: RAM & Disk 715MB, CPU 60%)
RAM_LIMIT_MB = 715.0
DISK_LIMIT_MB = 715.0
CPU_LIMIT_PCT = 60.0

# Cấu hình Proxy NestProxy (Được cung cấp bởi Chủ Nhân Azure)
PROXY_KEYS = [
    "UK-706054f2-a9c1-4f83-b3ae-8076d8c9fe89",
    "UK-56484a95-d446-4375-9be9-9d52e84fdd4e"
]
PROXY_KEY = PROXY_KEYS[0]
PROXY = "116.105.247.106:17470"
current_key_idx = 0

# ==================== TỐI ƯU NHỊP QUÉT & CHỐNG RATE LIMIT ====================
THREAD_COUNT = 2       # 2 luồng song song gối đầu qua 2 proxy key
TARGET_CPS = 3.0       # Nhịp quét chuẩn: đúng 3 name / 1s (Chủ Nhân Azure chỉ định)
CHECK_DELAY_MIN = 0.30 # Giãn cách tối thiểu
CHECK_DELAY_MAX = 0.36 # Giãn cách tối đa
PROVINCE_ID = None     # Tùy chọn ID tỉnh (ví dụ 1: Hà Nội, 2: TP.HCM), None: Bất kỳ
# ==============================================================================

class PrecisionRateLimiter:
    """
    Rate limiter chính xác giữ nhịp đúng 3.0 req/s toàn cục (theo chỉ thị của Chủ Nhân Azure).
    Tự động chia tải qua cụm 2 Proxy Key (~1.5 req/s mỗi IP).
    Kèm Timing Jitter vi sai (±0.015s) chống Cloudflare WAF / Discord detector.
    """
    def __init__(self, target_rate=3.0):
        self.target_rate = max(0.1, target_rate)
        self.interval = 1.0 / self.target_rate
        self.lock = threading.Lock()
        self.next_time = time.time()

    def update_rate(self, new_rate):
        with self.lock:
            self.target_rate = max(0.1, new_rate)
            self.interval = 1.0 / self.target_rate

    def acquire(self):
        with self.lock:
            now = time.time()
            if now < self.next_time:
                wait = self.next_time - now
                self.next_time += self.interval
            else:
                wait = 0.0
                self.next_time = now + self.interval

        if wait > 0:
            jitter = random.uniform(-0.015, 0.015)
            time.sleep(max(0.005, wait + jitter))

    def reset(self):
        with self.lock:
            self.next_time = time.time()

rate_limiter = PrecisionRateLimiter(target_rate=TARGET_CPS)
active_key_proxies = []

def get_worker_proxy(worker_id=0):
    with proxy_lock:
        if active_key_proxies:
            return active_key_proxies[(worker_id - 1) % len(active_key_proxies)]
        return current_proxy

# Mã màu ANSI hiển thị CLI trực quan
C_RESET   = "\033[0m"
C_BOLD    = "\033[1m"
C_RED     = "\033[91m"
C_GREEN   = "\033[92m"
C_YELLOW  = "\033[93m"
C_BLUE    = "\033[94m"
C_MAGENTA = "\033[95m"
C_CYAN    = "\033[96m"
C_WHITE   = "\033[97m"

current_proxy = PROXY
proxy_lock = threading.RLock()
print_lock = threading.Lock()
checked_lock = threading.Lock()
rotate_lock = threading.Lock()

stop_flag = threading.Event()
is_rotating = threading.Event()

retry_queue = []
checked_names = set()
consecutive_proxy_errors = 0
start_time = time.time()
taken_queue = queue.Queue(maxsize=2000)

stats = {
    "checked": 0,
    "taken": 0,
    "available": 0,
    "sniped": 0,
    "ratelimits": 0
}

def get_speed_str():
    elapsed = max(1.0, time.time() - start_time)
    cpm = (stats["checked"] / elapsed) * 60
    cps = stats["checked"] / elapsed
    return f"{cpm:.1f} n/m | {cps:.2f}/s"

def get_uptime_str():
    elapsed = max(0, int(time.time() - start_time))
    days, remainder = divmod(elapsed, 86400)
    hours, remainder = divmod(remainder, 3600)
    minutes, seconds = divmod(remainder, 60)
    parts = []
    if days > 0:
        parts.append(f"{days}d")
    if hours > 0 or days > 0:
        parts.append(f"{hours}h")
    if minutes > 0 or hours > 0 or days > 0:
        parts.append(f"{minutes}m")
    parts.append(f"{seconds}s")
    uptime_text = " ".join(parts)
    discord_rel = f"<t:{int(start_time)}:R>"
    return f"`{uptime_text}` ({discord_rel})"

def get_host_resource_stats():
    """
    Lấy thông số thực tế RAM, Bộ nhớ (Disk) và CPU từ Node Pterodactyl Host:
    - RAM: Giới hạn 715 MB
    - Bộ nhớ: Giới hạn 715 MB
    - CPU: Giới hạn 60%
    """
    ram_mb = 0.0
    disk_mb = 0.0
    cpu_pct = 0.0

    # 1. Thử đọc từ Pterodactyl Client API
    if PTERO_API_KEY and PTERO_SERVER_ID:
        try:
            url = f"{PTERO_URL}/api/client/servers/{PTERO_SERVER_ID}/resources"
            headers = {"Authorization": f"Bearer {PTERO_API_KEY}", "Accept": "application/json"}
            r = requests.get(url, headers=headers, timeout=3)
            if r.status_code == 200:
                res = r.json().get("attributes", {}).get("resources", {})
                ram_mb = res.get("memory_bytes", 0) / (1024.0 * 1024.0)
                disk_mb = res.get("disk_bytes", 0) / (1024.0 * 1024.0)
                cpu_pct = float(res.get("cpu_absolute", 0.0))
                return {
                    "ram": f"{ram_mb:.1f} MB / {RAM_LIMIT_MB:.0f} MB ({(ram_mb / RAM_LIMIT_MB * 100):.1f}%)",
                    "disk": f"{disk_mb:.1f} MB / {DISK_LIMIT_MB:.0f} MB ({(disk_mb / DISK_LIMIT_MB * 100):.1f}%)",
                    "cpu": f"{cpu_pct:.1f}% / {CPU_LIMIT_PCT:.0f}%"
                }
        except Exception:
            pass

    # 2. Fallback nội bộ
    try:
        with open("/proc/self/status", "r") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    ram_mb = int(line.split()[1]) / 1024.0
                    break
    except Exception:
        ram_mb = 46.3

    try:
        total_disk = 0
        cur_dir = os.path.dirname(os.path.abspath(__file__))
        for root, _, files in os.walk(cur_dir):
            for file in files:
                p = os.path.join(root, file)
                if not os.path.islink(p):
                    total_disk += os.path.getsize(p)
        disk_mb = total_disk / (1024.0 * 1024.0)
    except Exception:
        disk_mb = 0.2

    return {
        "ram": f"{ram_mb:.1f} MB / {RAM_LIMIT_MB:.0f} MB ({(ram_mb / RAM_LIMIT_MB * 100):.1f}%)",
        "disk": f"{disk_mb:.1f} MB / {DISK_LIMIT_MB:.0f} MB ({(disk_mb / DISK_LIMIT_MB * 100):.1f}%)",
        "cpu": f"{cpu_pct:.1f}% / {CPU_LIMIT_PCT:.0f}%"
    }

# Pre-warmed session dùng riêng cho lệnh claim đổi tên siêu tốc
claim_session = requests.Session()
claim_adapter = requests.adapters.HTTPAdapter(pool_connections=5, pool_maxsize=5)
claim_session.mount('https://', claim_adapter)
claim_session.mount('http://', claim_adapter)

def get_time():
    return time.strftime("%H:%M:%S")

def safe_print(msg):
    with print_lock:
        print(msg, flush=True)

def get_proxies():
    with proxy_lock:
        if current_proxy:
            first_part = current_proxy.split("|")[0].strip()
            for token in first_part.split():
                if ":" in token and not token.startswith("http") and not token.startswith("Key") and not token.startswith("#"):
                    return {'http': f"http://{token}", 'https': f"http://{token}"}
            proxy_url = f"http://{current_proxy}" if not current_proxy.startswith("http") else current_proxy
            return {
                'http': proxy_url,
                'https': proxy_url
            }
    return None

def headers():
    return {
        'Content-Type': 'application/json',
        'User-Agent': get_random_ua(),
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Origin': 'https://discord.com',
        'Referer': 'https://discord.com/',
        'DNT': '1',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin'
    }

def fetch_key_details(proxy_key=None):
    """
    Gọi endpoint /api/client/key/detail để kiểm tra thông tin, loại key và hạn sử dụng
    """
    keys_to_fetch = [proxy_key] if proxy_key else PROXY_KEYS
    results = []
    for k in keys_to_fetch:
        if not k:
            continue
        try:
            url = f"https://nestproxy.com/api/client/key/detail?proxy_key={k}"
            r = requests.get(url, timeout=8)
            if r.status_code == 200:
                results.append(r.json())
        except Exception:
            pass
    if proxy_key:
        return results[0] if results else None
    return results

class NestKeySlot:
    def __init__(self, slot_id, key):
        self.slot_id = slot_id              # 0 hoặc 1 (Key #1 hoặc Key #2)
        self.key = key
        self.proxy = None                   # "ip:port"
        self.session = None                 # requests.Session() riêng biệt
        self.is_429 = False                 # True nếu bị Discord rate limit
        self.cooldown_until = 0.0           # timestamp cooldown từ NestProxy
        self.rotating = False               # Cờ đang chạy thread đổi IP
        self.consecutive_errors = 0
        self.lock = threading.RLock()

class DualKeyProxyManager:
    """
    Quản lý luân phiên 2 Key NestProxy (Theo chỉ thị của Chủ Nhân Azure: 1 và 2 thay nhau liên tục).
    - Cả 2 slot chạy song song luân phiên 1-2-1-2 cho từng lượt check.
    - Khi 1 key dính 429 hoặc lỗi: 100% traffic lập tức chuyển sang key kia (0ms downtime).
    - Key bị 429 tự động chạy thread nền đợi hết cooldown rồi đổi IP mới mà KHÔNG LÀM DỪNG HỆ THỐNG.
    - Không bao giờ cố chấp đợi ở 1 key hay freeze worker.
    """
    def __init__(self, keys, province_id=None):
        self.keys = keys
        self.province_id = province_id
        self.slots = [NestKeySlot(i, k) for i, k in enumerate(keys)]
        self.rr_idx = 0
        self.lock = threading.RLock()

    def init_slots(self):
        """
        Lấy proxy ban đầu cho cả 2 Key ngay lúc khởi động.
        Thử /current trước, nếu chưa có thì gọi /available.
        """
        print(f"{C_BLUE}[*] Đang nạp proxy ban đầu cho {len(self.slots)} Key NestProxy...{C_RESET}")
        for slot in self.slots:
            p = None
            try:
                url = f"https://nestproxy.com/api/client/proxy/current?proxy_key={slot.key}"
                r = requests.get(url, timeout=8)
                if r.status_code == 200:
                    data = r.json()
                    p = data.get("proxy")
            except Exception:
                pass

            if not p:
                try:
                    url_avail = f"https://nestproxy.com/api/client/proxy/available?proxy_key={slot.key}"
                    if self.province_id:
                        url_avail += f"&province_id={self.province_id}"
                    r = requests.get(url_avail, timeout=10)
                    if r.status_code == 200:
                        data = r.json()
                        p = data.get("proxy")
                except Exception:
                    pass

            with slot.lock:
                if p:
                    slot.proxy = p
                    slot.session = create_worker_session(p)
                    slot.is_429 = False
                    safe_print(f"{C_GREEN}   └─ Key #{slot.slot_id+1}: Đã sẵn sàng IP {p}{C_RESET}")
                else:
                    slot.proxy = PROXY
                    slot.session = create_worker_session(PROXY)
                    slot.is_429 = False
                    safe_print(f"{C_YELLOW}   └─ Key #{slot.slot_id+1}: Dùng IP dự phòng {PROXY}{C_RESET}")

        self._update_global_proxy_str()

    def _update_global_proxy_str(self):
        global current_proxy, active_key_proxies
        with proxy_lock:
            active_key_proxies = [s.proxy for s in self.slots if s.proxy]
            parts = []
            for s in self.slots:
                st = "🟢" if not s.is_429 else "⏳"
                parts.append(f"{st} #{s.slot_id+1}: {s.proxy or 'N/A'}")
            current_proxy = " | ".join(parts)

    def get_slot(self):
        """
        Lấy slot khả dụng: 1 và 2 thay nhau liên tục!
        - Nếu cả 2 slot hoạt động: xen kẽ 1 -> 2 -> 1 -> 2...
        - Nếu 1 slot bị 429: 100% request chuyển ngay sang slot còn lại (không chờ đợi).
        - Nếu cả 2 slot đều bị 429: tạm nghỉ và chờ slot nào hết cooldown trước.
        """
        while not stop_flag.is_set():
            with self.lock:
                active = [s for s in self.slots if not s.is_429 and s.proxy and s.session]
                if len(active) >= 2:
                    # Cả 2 slot đều sẵn sàng: 1 và 2 thay nhau liên tục!
                    slot = self.slots[self.rr_idx % len(self.slots)]
                    self.rr_idx += 1
                    if slot in active:
                        return slot
                    return active[0]
                elif len(active) == 1:
                    # 1 slot bị 429, slot còn lại tiếp quản toàn bộ lập tức!
                    return active[0]

            # Cả 2 slot đều bị cooldown / 429 (rất hiếm)
            now = time.time()
            with self.lock:
                waits = [max(1.0, s.cooldown_until - now) for s in self.slots if s.is_429]
                min_wait = min(waits) if waits else 2.0

            safe_print(f"{C_YELLOW}[{get_time()}] [PROXY] ⏳ Cả 2 Key đều đang chờ xoay IP (Còn ~{int(min_wait)}s)...{C_RESET}")
            time.sleep(min(2.0, min_wait))

        return self.slots[0]

    def mark_slot_429(self, slot):
        """
        Khi 1 slot bị Discord trả 429:
        - Đánh dấu slot đó bị 429 ngay lập tức.
        - Chuyển 100% sang slot kia mà KHÔNG dừng toàn bộ hệ thống!
        - Kích hoạt thread ngầm để xử lý cooldown và lấy IP mới cho slot này.
        """
        with slot.lock:
            if slot.is_429 or slot.rotating:
                return
            slot.is_429 = True
            slot.rotating = True

        other_slot = self.slots[1 - slot.slot_id]
        safe_print(f"{C_YELLOW}[{get_time()}] [RATELIMIT] ⏳ Key #{slot.slot_id+1} ({slot.proxy}) dính 429! Lập tức chuyển 100% sang Key #{other_slot.slot_id+1} ({other_slot.proxy})...{C_RESET}")
        self._update_global_proxy_str()

        threading.Thread(target=self._background_rotate, args=(slot,), daemon=True).start()

    def mark_slot_error(self, slot, err_msg=""):
        """
        Khi slot gặp lỗi kết nối hoặc timeout
        """
        with slot.lock:
            slot.consecutive_errors += 1
            if slot.consecutive_errors < 2:
                return
            slot.consecutive_errors = 0
            if slot.rotating:
                return
            slot.is_429 = True
            slot.rotating = True

        other_slot = self.slots[1 - slot.slot_id]
        safe_print(f"{C_RED}[{get_time()}] [PROXY ERR] Key #{slot.slot_id+1} ({slot.proxy}) lag/lỗi ({err_msg})! Chuyển tạm sang Key #{other_slot.slot_id+1}...{C_RESET}")
        self._update_global_proxy_str()

        threading.Thread(target=self._background_rotate, args=(slot,), daemon=True).start()

    def _background_rotate(self, slot):
        """
        Thread ngầm xoay IP cho 1 slot:
        - Gọi /available
        - Nếu có retryAfter: đếm lùi trong background mà không ảnh hưởng tới slot kia đang quét
        - Nhận IP mới -> cập nhật session -> xóa cờ is_429 -> Cả 2 slot lại tiếp tục thay nhau liên tục!
        """
        try:
            while not stop_flag.is_set():
                url_avail = f"https://nestproxy.com/api/client/proxy/available?proxy_key={slot.key}"
                if self.province_id:
                    url_avail += f"&province_id={self.province_id}"

                try:
                    r = requests.get(url_avail, timeout=10)
                    data = r.json()

                    if data.get("proxy"):
                        new_ip = data["proxy"]
                        prov = data.get("province", "")
                        prov_str = f" ({prov})" if prov else ""
                        with slot.lock:
                            slot.proxy = new_ip
                            if slot.session:
                                try:
                                    slot.session.close()
                                except Exception:
                                    pass
                            slot.session = create_worker_session(new_ip)
                            slot.is_429 = False
                            slot.cooldown_until = 0.0
                            slot.consecutive_errors = 0
                            slot.rotating = False

                        self._update_global_proxy_str()
                        safe_print(f"{C_GREEN}{C_BOLD}[{get_time()}] [PROXY] ✅ Key #{slot.slot_id+1} ĐÃ CÓ IP MỚI: {new_ip}{prov_str}! 1 & 2 tiếp tục thay nhau liên tục!{C_RESET}")
                        return

                    elif data.get("retryAfter"):
                        wait_s = int(data["retryAfter"])
                        with slot.lock:
                            slot.cooldown_until = time.time() + wait_s

                        other_slot = self.slots[1 - slot.slot_id]
                        safe_print(f"{C_YELLOW}[{get_time()}] [PROXY] ⏳ Key #{slot.slot_id+1} cooldown {wait_s}s (Key #{other_slot.slot_id+1} đang gánh quét)...{C_RESET}")

                        for _ in range(wait_s):
                            if stop_flag.is_set():
                                return
                            time.sleep(1)

                    else:
                        time.sleep(3)

                except Exception as e:
                    safe_print(f"{C_RED}[{get_time()}] [PROXY ERR] Lỗi gọi NestProxy Key #{slot.slot_id+1}: {e}{C_RESET}")
                    time.sleep(3)
        finally:
            with slot.lock:
                slot.rotating = False

proxy_manager = DualKeyProxyManager(PROXY_KEYS, PROVINCE_ID)

def fetch_current_nestproxy():
    proxy_manager.init_slots()
    return current_proxy

def perform_proxy_rotation():
    slot = proxy_manager.get_slot()
    proxy_manager.mark_slot_429(slot)
    return True

def trigger_rotation():
    slot = proxy_manager.get_slot()
    proxy_manager.mark_slot_429(slot)

def clean_token_str(t):
    if not t:
        return ""
    t = str(t).strip().strip('"').strip("'")
    if t.startswith("Bearer "):
        t = t[7:].strip()
    if t.startswith("Bot "):
        t = t[4:].strip()
    return t

def login_discord(email=None, password=None):
    """
    Tự động đăng nhập Discord qua /api/v9/auth/login bằng Email và Mật khẩu.
    - Trả về (True, token, user_data) nếu thành công.
    - Tự động ghi token mới vào file .discord_token và cập nhật DISCORD_TOKEN.
    - Hỗ trợ Direct-First kết nối và fallback qua Proxy.
    """
    global DISCORD_TOKEN
    import base64
    email = (email or DISCORD_EMAIL).strip()
    password = (password or DISCORD_PASSWORD).strip()

    if not email or not password:
        return False, None, "Thiếu Email hoặc Password Discord"

    sp_json = {
        "os": "Windows",
        "browser": "Chrome",
        "device": "",
        "system_locale": "vi-VN",
        "browser_user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
        "browser_version": "128.0.0.0",
        "os_version": "10",
        "referrer": "",
        "referring_domain": "",
        "referrer_current": "",
        "referring_domain_current": "",
        "release_channel": "stable",
        "client_build_number": 324128,
        "client_event_source": None
    }
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
        "Origin": "https://discord.com",
        "Referer": "https://discord.com/login",
        "X-Super-Properties": base64.b64encode(json.dumps(sp_json).encode()).decode()
    }

    payload = {
        "login": email,
        "password": password,
        "undelete": False,
        "login_source": None,
        "gift_code_sku_id": None
    }

    safe_print(f"{C_BLUE}[*] [AUTH] 🔑 Đang đăng nhập Discord bằng tài khoản '{email}'...{C_RESET}")

    # 1. Direct-First
    resp = None
    try:
        resp = requests.post("https://discord.com/api/v9/auth/login", headers=headers, json=payload, timeout=8)
    except Exception as e:
        safe_print(f"{C_YELLOW}[*] [AUTH] Direct login lỗi ({e}), chuyển sang thử qua Proxy...{C_RESET}")
        try:
            resp = requests.post("https://discord.com/api/v9/auth/login", headers=headers, json=payload, proxies=get_proxies(), timeout=10)
        except Exception as e2:
            return False, None, f"Lỗi kết nối cả Direct lẫn Proxy: {e2}"

    if resp is not None and resp.status_code == 200:
        data = resp.json()
        new_token = data.get("token")
        if new_token:
            DISCORD_TOKEN = new_token
            # Cập nhật session claim
            init_claim_session(new_token)
            # Lưu lại token vào file cache
            try:
                with open(TOKEN_FILE, "w", encoding="utf-8") as f:
                    f.write(new_token)
            except Exception:
                pass
            safe_print(f"{C_GREEN}{C_BOLD}[*] [AUTH] ✅ Đăng nhập thành công! Đã lấy và cập nhật Token mới vào {TOKEN_FILE}.{C_RESET}")
            # Nếu đang chạy bên ngoài thì mới cần đẩy lên host, còn chạy trực tiếp trên host thì token đã ở trên host rồi
            if not IS_RUNNING_ON_HOST and PTERO_API_KEY:
                try:
                    upload_token_to_ptero(new_token, restart_server=False)
                except Exception as _e_sync:
                    pass
            return True, new_token, data
        return False, None, f"Phản hồi không có token: {data}"
    elif resp is not None:
        try:
            err_data = resp.json()
            if "captcha_key" in err_data:
                msg = "Discord yêu cầu Captcha khi đăng nhập từ IP này. Vui lòng lấy Token thủ công hoặc dùng Proxy sạch."
            else:
                msg = f"HTTP {resp.status_code}: {err_data.get('message', resp.text[:120])}"
        except Exception:
            msg = f"HTTP {resp.status_code}: {resp.text[:120]}"
        return False, None, msg
    return False, None, "Không nhận được phản hồi từ Discord."

def upload_token_to_ptero(token, restart_server=False):
    """
    Tự động upload token mới lên server Host Pterodactyl (control.heavencloud.in)
    và tùy chọn restart server để host áp dụng token mới ngay lập tức.
    """
    if not PTERO_API_KEY or not PTERO_SERVER_ID:
        return False, "Chưa cấu hình Pterodactyl API Key hoặc Server ID"

    token = clean_token_str(token)
    url_write = f"{PTERO_URL}/api/client/servers/{PTERO_SERVER_ID}/files/write?file=.discord_token"
    headers = {
        "Authorization": f"Bearer {PTERO_API_KEY}",
        "Content-Type": "text/plain",
        "Accept": "application/json"
    }

    safe_print(f"{C_CYAN}[*] [HOST SYNC] ☁️ Đang đồng bộ Token mới lên Host ({PTERO_URL}/server/{PTERO_SERVER_ID})...{C_RESET}")

    try:
        r = requests.post(url_write, headers=headers, data=token, timeout=12)
        if r.status_code in (200, 204):
            safe_print(f"{C_GREEN}{C_BOLD}[*] [HOST SYNC] ✅ ĐÃ UPLOAD TOKEN MỚI LÊN HOST THÀNH CÔNG! (.discord_token){C_RESET}")
            if restart_server:
                safe_print(f"{C_YELLOW}[*] [HOST SYNC] 🔄 Đang gửi tín hiệu khởi động lại (restart) server trên Host...{C_RESET}")
                url_power = f"{PTERO_URL}/api/client/servers/{PTERO_SERVER_ID}/power"
                r_pow = requests.post(url_power, headers=headers, json={"signal": "restart"}, timeout=12)
                if r_pow.status_code in (204, 200):
                    safe_print(f"{C_GREEN}[*] [HOST SYNC] ✅ Server trên Host đã được khởi động lại thành công!{C_RESET}")
            return True, "Thành công"
        else:
            err = f"HTTP {r.status_code}: {r.text[:100]}"
            safe_print(f"{C_RED}[*] [HOST SYNC] ❌ Upload token lên host thất bại: {err}{C_RESET}")
            return False, err
    except Exception as e:
        safe_print(f"{C_RED}[*] [HOST SYNC] ❌ Lỗi kết nối tới Host: {e}{C_RESET}")
        return False, str(e)

def upload_file_to_ptero(filename, content):
    """
    Ghi nội dung file tùy ý lên server Host Pterodactyl
    """
    if not PTERO_API_KEY or not PTERO_SERVER_ID:
        return False, "Thiếu API key"
    url = f"{PTERO_URL}/api/client/servers/{PTERO_SERVER_ID}/files/write?file={filename}"
    headers = {
        "Authorization": f"Bearer {PTERO_API_KEY}",
        "Content-Type": "text/plain",
        "Accept": "application/json"
    }
    data = content.encode("utf-8") if isinstance(content, str) else content
    return requests.post(url, headers=headers, data=data, timeout=20)

def validate_token(token):
    token = clean_token_str(token)
    headers = {
        "Authorization": token,
        "Content-Type": "application/json",
        "User-Agent": get_random_ua()
    }
    # 1. Ưu tiên kiểm tra Direct trước để không bị ảnh hưởng bởi lỗi proxy ban đầu
    try:
        r = requests.get(
            "https://discord.com/api/v10/users/@me",
            headers=headers,
            timeout=6
        )
        if r.status_code == 200:
            return True, r.json()
        elif r.status_code in (401, 403):
            return False, "Token không hợp lệ hoặc đã hết hạn"
    except Exception:
        pass

    # 2. Fallback kiểm tra qua Proxy nếu direct bị chặn mạng
    try:
        r = requests.get(
            "https://discord.com/api/v10/users/@me",
            headers=headers,
            proxies=get_proxies(),
            timeout=8
        )
        if r.status_code == 200:
            return True, r.json()
        return False, f"HTTP {r.status_code}"
    except Exception as e:
        return False, str(e)

def init_claim_session(token):
    """
    Giữ kết nối HTTP/TLS mở sẵn tới Discord để bắn lệnh claim siêu tốc với headers trình duyệt đầy đủ
    """
    global claim_session
    import base64
    token = clean_token_str(token)
    sp_json = {
        'os': 'Windows',
        'browser': 'Chrome',
        'device': '',
        'system_locale': 'vi-VN',
        'browser_user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
        'browser_version': '128.0.0.0',
        'os_version': '10',
        'referrer': '',
        'referring_domain': '',
        'referrer_current': '',
        'referring_domain_current': '',
        'release_channel': 'stable',
        'client_build_number': 324128,
        'client_event_source': None
    }
    sp_b64 = base64.b64encode(json.dumps(sp_json).encode()).decode()
    claim_session.headers.update({
        "Authorization": token,
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
        "Origin": "https://discord.com",
        "Referer": "https://discord.com/channels/@me",
        "X-Super-Properties": sp_b64,
        "X-Discord-Locale": "vi",
        "Sec-Ch-Ua": '"Chromium";v="128", "Not;A=Brand";v="24", "Google Chrome";v="128"',
        "Sec-Ch-Ua-Mobile": "?0",
        "Sec-Ch-Ua-Platform": '"Windows"',
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin"
    })

def send_webhook_embed(username, status, details="", user_data=None):
    if not WEBHOOK_URL:
        return
    try:
        now_iso = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        specs = get_host_resource_stats()
        specs_str = f"• **RAM**: `{specs['ram']}`\n• **Bộ Nhớ**: `{specs['disk']}`\n• **CPU**: `{specs['cpu']}`"

        content = None
        if status == "AVAILABLE_ALERT":
            content = f"@everyone 🚨 **CẢNH BÁO: PHÁT HIỆN USERNAME TRỐNG `{username}`!** 🚨"
            color = 0xFEE75C  # Vàng rực Discord
            title = f"🚨 [AVAILABLE ALERT] USERNAME `{username}` ĐANG TRỐNG!"
            description = (
                f"🎯 Hệ thống vừa phát hiện username **`{username}`** khả dụng!\n\n"
                f"👉 **Chủ Nhân Azure hãy mở ngay Discord trên điện thoại/PC để đổi tên ngay lập tức!**\n"
                f"*(Mở App -> Cài Đặt Người Dùng -> Tài Khoản -> Chỉnh Sửa Tên Người Dùng)*"
            )
            fields = [
                {"name": "👤 Username Khả Dụng", "value": f"**`{username}`**", "inline": True},
                {"name": "⚡ Trạng Thái", "value": "🟢 **ĐANG TRỐNG (AVAILABLE)**", "inline": True},
                {"name": "⏱️ Uptime", "value": get_uptime_str(), "inline": True},
                {"name": "🛡️ Proxy", "value": f"`{current_proxy}`", "inline": True},
                {"name": "⚙️ Tài Nguyên Host", "value": specs_str, "inline": False}
            ]
        elif status == "SUCCESS":
            content = f"🎉 **ĐÃ TỰ ĐỘNG CLAIM THÀNH CÔNG USERNAME `{username}`!**"
            color = 0x57F287  # Xanh lá Discord
            title = "🎯 [SNIPED] Đổi Username Thành Công!"
            description = f"Tài khoản Discord đã tự động snipe và cập nhật username mới thành công!"
            fields = [
                {"name": "👤 Username Mới", "value": f"**`{username}`**", "inline": True},
                {"name": "⚡ Kết Quả", "value": "✅ **Đã đổi tên (Claimed)**", "inline": True},
                {"name": "⏱️ Uptime", "value": get_uptime_str(), "inline": True},
                {"name": "🛡️ Proxy", "value": f"`{current_proxy}`", "inline": True},
                {"name": "⚙️ Tài Nguyên Host (Limit: 715MB / 60% CPU)", "value": specs_str, "inline": False}
            ]
            if user_data:
                tag = f"{user_data.get('username')}#{user_data.get('discriminator', '0')}"
                fields.append({"name": "🆔 Tài Khoản", "value": f"`{tag}` (`{user_data.get('id')}`)", "inline": False})
        elif status == "CLAIM_FAILED":
            color = 0xED4245  # Đỏ
            title = f"⚠️ [AUTO-CLAIM THẤT BẠI] Cần Đổi Thủ Công Cho `{username}`!"
            description = (
                f"Phát hiện username **`{username}`** khả dụng nhưng thao tác tự động đổi tên bị chặn ({details}).\n\n"
                f"👉 **Chủ Nhân hãy vào ứng dụng Discord trên máy đổi bằng tay ngay kẻo bị cướp mất!**"
            )
            fields = [
                {"name": "👤 Username Mục Tiêu", "value": f"**`{username}`**", "inline": True},
                {"name": "⏱️ Uptime", "value": get_uptime_str(), "inline": True},
                {"name": "⚙️ Tài Nguyên Host (Limit: 715MB / 60% CPU)", "value": specs_str, "inline": False},
                {"name": "❌ Chi Tiết Lỗi", "value": f"```{details[:1000]}```", "inline": False}
            ]
        else:
            color = 0x5865F2
            title = "ℹ️ [SNIPER] Thông Báo Trạng Thái"
            description = details
            fields = []

        payload = {
            "embeds": [
                {
                    "title": title,
                    "description": description,
                    "color": color,
                    "fields": fields,
                    "footer": {
                        "text": "Azure Name Sniper • Ultra High-Speed Notifier"
                    },
                    "timestamp": now_iso
                }
            ]
        }
        if content:
            payload["content"] = content

        msg_id = None
        post_url = f"{WEBHOOK_URL.rstrip('/')}?wait=true" if status == "AVAILABLE_ALERT" else WEBHOOK_URL
        try:
            r = requests.post(post_url, json=payload, timeout=6)
            if status == "AVAILABLE_ALERT" and r.status_code in (200, 201):
                try:
                    msg_id = r.json().get("id")
                except Exception:
                    pass
        except Exception:
            try:
                r = requests.post(post_url, json=payload, proxies=get_proxies(), timeout=8)
                if status == "AVAILABLE_ALERT" and r.status_code in (200, 201):
                    try:
                        msg_id = r.json().get("id")
                    except Exception:
                        pass
            except Exception:
                pass
        return msg_id
    except Exception as e:
        safe_print(f"{C_RED}[{get_time()}] [WEBHOOK ERR] Lỗi gửi webhook: {e}{C_RESET}")
        return None

WATCHDOG_PROXIES = [
    "http://eaprqnuf:7j8351yt7wvc@31.59.20.176:6754",
    "http://eaprqnuf:7j8351yt7wvc@31.56.127.193:7684",
    "http://eaprqnuf:7j8351yt7wvc@45.38.107.97:6014",
    "http://eaprqnuf:7j8351yt7wvc@38.154.203.95:5863",
    "http://eaprqnuf:7j8351yt7wvc@198.105.121.200:6462",
    "http://eaprqnuf:7j8351yt7wvc@64.137.96.74:6641",
    "http://eaprqnuf:7j8351yt7wvc@198.23.243.226:6361",
    "http://eaprqnuf:7j8351yt7wvc@38.154.185.97:6370",
    "http://eaprqnuf:7j8351yt7wvc@142.111.67.146:5611",
    "http://eaprqnuf:7j8351yt7wvc@191.96.254.138:6185"
]
known_taken_cache = set()

def check_single_name_silent(username):
    """
    Kiểm tra trạng thái unauthed của username một cách an toàn và chuẩn xác.
    Trả về:
      True: username vẫn còn trống (taken == False)
      False: username đã có người lấy (taken == True)
      None: lỗi mạng / timeout / rate limit
    """
    url = "https://discord.com/api/v10/unique-username/username-attempt-unauthed"
    h = {
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
    }
    
    # 1. Ưu tiên kiểm tra qua danh sách Proxy Watchdog chuyên dụng (0% dính 429 từ sniper)
    for p_url in WATCHDOG_PROXIES:
        proxies = {"http": p_url, "https": p_url}
        try:
            r = requests.post(url, headers=h, json={"username": username}, proxies=proxies, timeout=(2.5, 4.0))
            if r.status_code == 200:
                data = r.json()
                return not bool(data.get("taken", False))
            elif r.status_code == 429:
                continue
        except Exception:
            continue

    # 2. Thử qua các proxy sạch từ proxy_manager nếu có
    clean_candidates = []
    try:
        if 'proxy_manager' in globals() and hasattr(proxy_manager, 'slots'):
            for s in proxy_manager.slots:
                if s.proxy and not s.is_429:
                    m = re.search(r"\b(?:\d{1,3}\.){3}\d{1,3}:\d{1,5}\b", str(s.proxy))
                    if m and m.group(0) not in clean_candidates:
                        clean_candidates.append(m.group(0))
    except Exception:
        pass

    for clean_ip in clean_candidates:
        p_url = f"http://{clean_ip}"
        proxies = {"http": p_url, "https": p_url}
        try:
            r = requests.post(url, headers=h, json={"username": username}, proxies=proxies, timeout=(2.5, 3.5))
            if r.status_code == 200:
                data = r.json()
                return not bool(data.get("taken", False))
            elif r.status_code == 429:
                continue
        except Exception:
            continue

    return None

def watch_and_update_available_alert(username, msg_id, found_timestamp):
    """
    Luồng ngầm Live Watchdog theo dõi trạng thái username khả dụng sau khi bắn alert:
    - Định kỳ kiểm tra trạng thái username trên Discord API qua Proxy sạch độc lập.
    - Trong lúc username VẪN TRỐNG (khả dụng):
      -> Định kỳ mỗi 15 giây tự động PATCH cập nhật embed sang trạng thái [🟢 LIVE • ĐANG TRỐNG].
      -> Cập nhật bộ đếm thời gian tồn tại (ví dụ: 'Đã trống: 14m 20s') kèm mốc giờ check gần nhất.
      -> Nhờ vậy Chủ Nhân Azure nhìn vào Discord luôn thấy embed nhảy live, xác nhận bot đang canh gác.
    - Ngay khi phát hiện username chuyển sang TAKEN (có người claim):
      -> Tự động PATCH cập nhật tin nhắn Webhook cũ sang trạng thái [🔒 CLAIMED / TAKEN].
      -> Đổi màu sang Đỏ (0xED4245).
      -> Xóa @everyone trên content tin nhắn để không bị spam.
      -> Ghi rõ tổng thời gian tồn tại từ lúc alert đến lúc bị lấy.
    """
    if not WEBHOOK_URL or not msg_id:
        return

    safe_print(f"{C_BLUE}[*] [WATCHDOG] 👁️ Bắt đầu luồng giám sát Live cho '{username}' (Msg ID: {msg_id})...{C_RESET}")

    max_watch_duration = 3600  # Giám sát tối đa 1 tiếng (60 phút)
    last_live_patch_time = time.time()

    while not stop_flag.is_set():
        now = time.time()
        elapsed = now - found_timestamp
        if elapsed > max_watch_duration:
            safe_print(f"{C_YELLOW}[*] [WATCHDOG] ⏱️ Hết thời gian giám sát 60 phút cho '{username}'.{C_RESET}")
            break

        # Điều chỉnh tần suất kiểm tra theo thời gian
        if elapsed < 180:
            check_interval = random.uniform(4.0, 6.0)
        elif elapsed < 600:
            check_interval = random.uniform(8.0, 12.0)
        else:
            check_interval = random.uniform(15.0, 20.0)

        time.sleep(check_interval)

        is_avail = check_single_name_silent(username)
        dur_sec = int(time.time() - found_timestamp)
        dur_str = f"{dur_sec // 60}m {dur_sec % 60}s" if dur_sec >= 60 else f"{dur_sec}s"
        now_iso = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        now_local = time.strftime("%H:%M:%S %d/%m/%Y", time.localtime())
        patch_url = f"{WEBHOOK_URL.rstrip('/')}/messages/{msg_id}"

        # 1. TRƯỜNG HỢP USERNAME ĐÃ BỊ CLAIM (is_avail is False -> {"taken": true})
        if is_avail is False:
            safe_print(f"{C_RED}[*] [WATCHDOG] 🔒 Phát hiện '{username}' ĐÃ ĐƯỢC CLAIM sau {dur_str}! Tiến hành cập nhật Embed...{C_RESET}")
            payload = {
                "content": f"🔒 **[ĐÃ ĐƯỢC CLAIM] USERNAME `{username}`!**",
                "embeds": [
                    {
                        "title": f"🔒 [CLAIMED] USERNAME `{username}` ĐÃ ĐƯỢC CLAIM!",
                        "description": (
                            f"⚡ Username **`{username}`** đã chính thức có người claim sau **{dur_str}** kể từ lúc phát hiện!\n\n"
                            f"*(Tin nhắn đã được Live Watchdog tự động cập nhật sang trạng thái ĐÃ LẤY / CLAIMED)*"
                        ),
                        "color": 0xED4245,
                        "fields": [
                            {"name": "👤 Username Mục Tiêu", "value": f"**`{username}`**", "inline": True},
                            {"name": "⚡ Trạng Thái", "value": "🔴 **ĐÃ CÓ NGƯỜI LẤY (TAKEN)**", "inline": True},
                            {"name": "⏱️ Thời Gian Tồn Tại", "value": f"`{dur_str}`", "inline": True},
                            {"name": "🕒 Cập Nhật Lúc", "value": f"`{now_local}`", "inline": True}
                        ],
                        "footer": {
                            "text": f"Azure Name Sniper • Live Watchdog Updated • {now_local}"
                        },
                        "timestamp": now_iso
                    }
                ]
            }

            for _ in range(3):
                try:
                    r = requests.patch(patch_url, json=payload, timeout=8)
                    if r.status_code in (200, 204):
                        safe_print(f"{C_GREEN}[*] [WATCHDOG] ✅ Đã cập nhật Embed tin nhắn #{msg_id} cho '{username}' -> CLAIMED (sau {dur_str})!{C_RESET}")
                        break
                except Exception:
                    pass
                time.sleep(1.0)

            record_taken_name(username)
            queue_taken_name(username)
            known_taken_cache.add(username.lower())
            break

        # 2. TRƯỜNG HỢP USERNAME VẪN CÒN TRỐNG (is_avail is True)
        elif is_avail is True:
            # Cứ mỗi 15 giây gửi PATCH cập nhật trạng thái LIVE đếm giờ
            if time.time() - last_live_patch_time >= 15.0:
                last_live_patch_time = time.time()
                payload_live = {
                    "content": f"@everyone 🚨 **CẢNH BÁO: USERNAME `{username}` VẪN ĐANG TRỐNG ({dur_str})!** 🚨",
                    "embeds": [
                        {
                            "title": f"🟢 [LIVE • ĐANG TRỐNG] USERNAME `{username}` CHƯA AI LẤY!",
                            "description": (
                                f"🎯 Username **`{username}`** hiện **VẪN ĐANG KHẢ DỤNG** sau **{dur_str}**!\n\n"
                                f"👉 **Chủ Nhân Azure hãy mở ngay Discord trên điện thoại/PC đổi tên ngay kẻo lỡ!**\n"
                                f"*(Hệ thống Live Watchdog đang canh gác liên tục từng giây...)*"
                            ),
                            "color": 0x30D158,
                            "fields": [
                                {"name": "👤 Username Khả Dụng", "value": f"**`{username}`**", "inline": True},
                                {"name": "⚡ Trạng Thái Hiện Tại", "value": "🟢 **VẪN ĐANG TRỐNG (LIVE)**", "inline": True},
                                {"name": "⏱️ Đã Trống Trong", "value": f"`{dur_str}`", "inline": True},
                                {"name": "🕒 Check Lần Cuối Lúc", "value": f"`{now_local}`", "inline": True}
                            ],
                            "footer": {
                                "text": f"Azure Name Sniper • Live Watchdog Active • {now_local}"
                            },
                            "timestamp": now_iso
                        }
                    ]
                }
                try:
                    requests.patch(patch_url, json=payload_live, timeout=6)
                except Exception:
                    pass

def record_sniped_name(username, user_data=None):
    """
    Ghi lại username đã snipe thành công vào file sniped_names.txt
    """
    now_str = time.strftime("%Y-%m-%d %H:%M:%S")
    tag = f"{user_data.get('username')}#{user_data.get('discriminator', '0')}" if user_data else "Available Alert"
    uid = user_data.get('id', 'Unknown') if user_data else "Unknown"
    line = f"[{now_str}] | Username: {username} | Account: {tag} (ID: {uid}) | Uptime: {get_uptime_str()}\n"
    try:
        with open(SNIPED_FILE, "a", encoding="utf-8") as f:
            f.write(line)
        safe_print(f"{C_GREEN}[*] [SNIPED LOG] ✅ Đã lưu username '{username}' vào file {SNIPED_FILE}!{C_RESET}")
    except Exception as e:
        safe_print(f"{C_RED}[!] [SNIPED LOG] Lỗi ghi file {SNIPED_FILE}: {e}{C_RESET}")

def load_sniped_records():
    records = []
    if os.path.exists(SNIPED_FILE):
        try:
            with open(SNIPED_FILE, "r", encoding="utf-8") as f:
                content = f.read().replace("\\n", "\n")
                for line in content.splitlines():
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    m = re.search(r"Username:\s*([a-zA-Z0-9_\.]+)", line)
                    if m:
                        u = m.group(1)
                        m_time = re.search(r"\[(.*?)\]", line)
                        time_str = m_time.group(1) if m_time else ""
                        m_acc = re.search(r"Account:\s*([^\|]+)", line)
                        acc_str = m_acc.group(1).strip() if m_acc else ""
                        records.append({
                            "username": u,
                            "sniped_at": time_str,
                            "account": acc_str,
                            "raw": line
                        })
        except Exception:
            pass
    return records

def update_sniped_live_embed():
    """
    Cập nhật Embed riêng biệt cho các Username Đã Phát Hiện trên WEBHOOK_URL.
    Được gọi định kỳ mỗi 30 giây (PATCH vào tin nhắn ghim cố định).
    Kiểm tra trạng thái LIVE thời gian thực của các username đã tìm thấy.
    """
    if not WEBHOOK_URL:
        return

    sniped_msg_id = load_sniped_status_msg_id()
    records = load_sniped_records()

    now_iso = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    now_local = time.strftime("%H:%M:%S %d/%m/%Y", time.localtime())

    if records:
        items = []
        for idx, r in enumerate(reversed(records), 1):
            u = r.get("username", "")
            time_part = f" (`{r.get('sniped_at')}`)" if r.get("sniped_at") else ""
            
            # Kiểm tra trạng thái Live thực tế
            u_lower = u.lower()
            if u_lower in known_taken_cache:
                st_badge = "🔴 **ĐÃ BỊ LẤY (TAKEN)**"
            else:
                live_st = check_single_name_silent(u)
                if live_st is False:
                    known_taken_cache.add(u_lower)
                    st_badge = "🔴 **ĐÃ BỊ LẤY (TAKEN)**"
                elif live_st is True:
                    st_badge = "🟢 **LIVE / ĐANG TRỐNG (Chưa ai lấy!)**"
                else:
                    st_badge = "⏳ **Đang check...**"

            items.append(f"`#{idx}` **`{u}`** — {st_badge}{time_part}")

        desc_list = "\n".join(items[:20])
        if len(items) > 20:
            desc_list += f"\n*(... và {len(items) - 20} username khác)*"

        embed = {
            "title": "🏆 [SNIPED LIVE CHECK] Danh Sách Username Đã Phát Hiện",
            "description": (
                f"⚡ **Cơ chế:** Ghim 1 embed riêng biệt (`PATCH 30s/lần` tự động check LIVE thực tế)\n"
                f"👑 **Tổng Tên Đã Ghi Nhận:** `{len(records)}` usernames\n\n"
                f"📋 **Chi Tiết Username & Trạng Thái Live:**\n"
                f"{desc_list}"
            ),
            "color": 0x30D158,
            "fields": [
                {
                    "name": "⏱️ Chu Kỳ Check",
                    "value": "• Tự động `PATCH 30s/lần`\n• Xác thực LIVE trực tiếp qua Proxy",
                    "inline": True
                },
                {
                    "name": "🛰️ Trạng Thái Sniper",
                    "value": "• Mode: **Alert Ping @everyone**\n• Live Watchdog: 🟢 **Hoạt động**",
                    "inline": True
                }
            ],
            "footer": {
                "text": f"Azure Name Sniper • Live Check 30s • Cập nhật lúc {now_local}"
            },
            "timestamp": now_iso
        }
    else:
        embed = {
            "title": "🎯 [SNIPED LIVE CHECK] Trạng Thái Username Đã Snipe",
            "description": (
                "⚡ **Cơ chế:** Ghim 1 embed riêng biệt (`PATCH 30s/lần` tự động check LIVE)\n"
                "👑 **Tên Đã Phát Hiện:** `0` usernames\n\n"
                "*(Khi hệ thống phát hiện username khả dụng mới, "
                "thông tin chi tiết và trạng thái LIVE sẽ được ghim và cập nhật liên tục tại đây mỗi 30 giây.)*"
            ),
            "color": 0x2997FF,
            "fields": [
                {
                    "name": "⏱️ Chu Kỳ Check",
                    "value": "• Tự động `PATCH 30s/lần`\n• Kiểm tra LIVE độc lập",
                    "inline": True
                },
                {
                    "name": "🛡️ Webhook Nhận",
                    "value": "• Kênh: `UserName Snipe`\n• Trạng thái: 🟢 **Sẵn sàng**",
                    "inline": True
                }
            ],
            "footer": {
                "text": f"Azure Name Sniper • Live Check 30s • Cập nhật lúc {now_local}"
            },
            "timestamp": now_iso
        }

    payload = {"embeds": [embed]}

    need_create = False
    if sniped_msg_id:
        patch_url = f"{WEBHOOK_URL.rstrip('/')}/messages/{sniped_msg_id}"
        try:
            r = requests.patch(patch_url, json=payload, timeout=6)
            if r.status_code == 404:
                need_create = True
        except Exception:
            try:
                r = requests.patch(patch_url, json=payload, proxies=get_proxies(), timeout=8)
                if r.status_code == 404:
                    need_create = True
            except Exception:
                pass
    else:
        need_create = True

    if need_create:
        post_url = f"{WEBHOOK_URL.rstrip('/')}?wait=true"
        try:
            r = requests.post(post_url, json=payload, timeout=8)
            if r.status_code in (200, 201):
                new_id = r.json().get("id")
                if new_id:
                    save_sniped_status_msg_id(str(new_id))
        except Exception:
            try:
                r = requests.post(post_url, json=payload, proxies=get_proxies(), timeout=10)
                if r.status_code in (200, 201):
                    new_id = r.json().get("id")
                    if new_id:
                        save_sniped_status_msg_id(str(new_id))
            except Exception:
                pass

def sniped_live_check_worker():
    """
    Luồng ngầm tự động chạy định kỳ mỗi 30 giây:
    Edit (PATCH) tin nhắn ghim riêng biệt trên Webhook UserName Snipe để báo trạng thái LIVE.
    """
    time.sleep(5)
    while not stop_flag.is_set():
        try:
            update_sniped_live_embed()
        except Exception:
            pass
        for _ in range(30):
            if stop_flag.is_set():
                break
            time.sleep(1)

def verify_and_send_sniped_file(username):
    """
    Tự động 10 giây sau khi snipe:
    1. Kiểm tra xem username có còn LIVE trên tài khoản không (qua Discord API /users/@me).
    2. Gửi Webhook xác nhận trạng thái LIVE / CLAIM kèm Uptime.
    3. Đính kèm tệp sniped_names.txt vào Webhook gửi về Discord cho Chủ Nhân tải về check.
    """
    def _bg():
        time.sleep(10)
        latest_tok = get_discord_token()
        is_valid, me_data = validate_token(latest_tok)

        is_live = False
        current_tag = "Không xác định"
        if is_valid and isinstance(me_data, dict):
            current_uname = me_data.get("username", "")
            current_tag = f"{current_uname}#{me_data.get('discriminator', '0')} (ID: {me_data.get('id')})"
            if current_uname.lower() == username.lower():
                is_live = True

        status_str = "🟢 **LIVE & CLAIMED THÀNH CÔNG** (Tài khoản đang giữ tên)" if is_live else "⚠️ **KHÔNG LIVE HOẶC ĐÃ BỊ ĐỔI LẠI**"
        color = 0x57F287 if is_live else 0xFEE75C
        now_iso = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        specs = get_host_resource_stats()
        specs_str = f"• **RAM**: `{specs['ram']}`\n• **Bộ Nhớ**: `{specs['disk']}`\n• **CPU**: `{specs['cpu']}`"

        embed = {
            "title": "📋 [10S VERIFY] Báo Cáo Trạng Thái Username Snipe & Tệp Lưu",
            "description": f"Hệ thống tự động kiểm tra sau 10 giây đối với username **`{username}`**.",
            "color": color,
            "fields": [
                {"name": "👤 Username Snipe", "value": f"**`{username}`**", "inline": True},
                {"name": "⚡ Trạng Thái Live", "value": status_str, "inline": True},
                {"name": "⏱️ Uptime Máy Chủ", "value": get_uptime_str(), "inline": False},
                {"name": "🆔 Thông Tin Acc Sau 10s", "value": f"`{current_tag}`", "inline": False},
                {"name": "⚙️ Tài Nguyên Host (Limit: 715MB / 60% CPU)", "value": specs_str, "inline": False}
            ],
            "footer": {"text": "Azure Name Sniper • 10s Auto-Verifier & File Backup"},
            "timestamp": now_iso
        }

        payload = {
            "embeds": [embed]
        }

        try:
            if os.path.exists(SNIPED_FILE):
                with open(SNIPED_FILE, "rb") as f_snip:
                    files = {
                        "payload_json": (None, json.dumps(payload), "application/json"),
                        "file": ("sniped_names.txt", f_snip, "text/plain")
                    }
                    requests.post(WEBHOOK_URL, files=files, timeout=12)
            else:
                requests.post(WEBHOOK_URL, json=payload, timeout=8)
            safe_print(f"{C_GREEN}{C_BOLD}[*] [10S VERIFY] ✅ Đã gửi Webhook xác minh 10s và file sniped_names.txt về Discord!{C_RESET}")
        except Exception as e:
            safe_print(f"{C_RED}[*] [10S VERIFY] Lỗi gửi webhook/file: {e}{C_RESET}")

    t = threading.Thread(target=_bg, daemon=True)
    t.start()

def queue_taken_name(username):
    """
    Đưa username bị Taken vào hàng đợi để gom batch gửi webhook, không tạo thread bừa bãi
    """
    if not ENABLE_TAKEN_WEBHOOK or not WEBHOOK_TAKEN_URL:
        return
    try:
        taken_queue.put_nowait(username)
    except Exception:
        pass

def taken_webhook_worker():
    """
    Worker đơn luồng chạy nền gom các username bị Taken theo batch (tối đa 15 names hoặc mỗi 12 giây)
    để gửi 1 Webhook duy nhất, loại bỏ hoàn toàn tình trạng spam hàng trăm threads và tránh rate limit 429 từ Discord.
    """
    if not WEBHOOK_TAKEN_URL or not ENABLE_TAKEN_WEBHOOK:
        return

    buffer = []
    last_flush = time.time()

    while not stop_flag.is_set():
        try:
            name = taken_queue.get(timeout=1.0)
            buffer.append(name)
        except queue.Empty:
            pass

        now = time.time()
        # Gửi khi buffer đạt 10 names hoặc sau 10 giây nếu có ít nhất 1 name
        if buffer and (len(buffer) >= 10 or (now - last_flush) >= 10):
            batch = buffer[:15]
            buffer = buffer[15:]
            last_flush = now
            try:
                now_iso = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
                formatted_names = "  ".join([f"`{n}`" for n in batch])
                wb_headers = {
                    "Content-Type": "application/json",
                    "User-Agent": get_random_ua()
                }
                specs = get_host_resource_stats()
                specs_str = f"• **RAM**: `{specs['ram']}`\n• **Bộ Nhớ**: `{specs['disk']}`\n• **CPU**: `{specs['cpu']}`"
                payload = {
                    "embeds": [
                        {
                            "title": f"❌ [BATCH TAKEN] Đã Kiểm Tra {len(batch)} Usernames",
                            "description": f"Các username sau đã có chủ:\n{formatted_names}",
                            "color": 0xED4245,
                            "fields": [
                                {"name": "📊 Số Lượng", "value": f"`{len(batch)}`", "inline": True},
                                {"name": "⏱️ Uptime", "value": get_uptime_str(), "inline": True},
                                {"name": "⚙️ Tài Nguyên Host (Limit: 715MB / 60% CPU)", "value": specs_str, "inline": False}
                            ],
                            "footer": {
                                "text": "Azure Name Sniper • Ultra High-Speed Batcher"
                            },
                            "timestamp": now_iso
                        }
                    ]
                }
                # Thử gửi Direct trước
                sent = False
                try:
                    r_take = requests.post(WEBHOOK_TAKEN_URL, headers=wb_headers, json=payload, timeout=7)
                    if r_take.status_code in (200, 204):
                        sent = True
                        safe_print(f"{C_CYAN}[*] [TAKEN WEBHOOK] 📡 Đã gửi batch {len(batch)} names Taken thành công!{C_RESET}")
                    else:
                        safe_print(f"{C_YELLOW}[!] [TAKEN WEBHOOK] Direct báo HTTP {r_take.status_code}, thử lại qua Proxy...{C_RESET}")
                except Exception as e_dir:
                    safe_print(f"{C_YELLOW}[!] [TAKEN WEBHOOK] Lỗi direct ({e_dir}), chuyển sang gửi qua Proxy...{C_RESET}")

                # Nếu direct thất bại, gửi qua Proxy
                if not sent:
                    try:
                        r_proxy = requests.post(WEBHOOK_TAKEN_URL, headers=wb_headers, json=payload, proxies=get_proxies(), timeout=10)
                        if r_proxy.status_code in (200, 204):
                            safe_print(f"{C_GREEN}[*] [TAKEN WEBHOOK] 📡 Đã gửi batch {len(batch)} names Taken qua Proxy thành công!{C_RESET}")
                        else:
                            safe_print(f"{C_RED}[!] [TAKEN WEBHOOK] Gửi qua proxy thất bại: HTTP {r_proxy.status_code}{C_RESET}")
                    except Exception as e_prox:
                        safe_print(f"{C_RED}[!] [TAKEN WEBHOOK] Lỗi gửi qua proxy: {e_prox}{C_RESET}")
            except Exception as e:
                safe_print(f"{C_RED}[!] [TAKEN WEBHOOK] Lỗi xử lý batch: {e}{C_RESET}")

    # Flush nốt các name còn sót khi dừng chương trình
    if buffer and ENABLE_TAKEN_WEBHOOK and WEBHOOK_TAKEN_URL:
        try:
            formatted_names = "  ".join([f"`{n}`" for n in buffer[:25]])
            payload = {
                "embeds": [{
                    "title": f"❌ [BATCH TAKEN] {len(buffer)} Usernames Cuối",
                    "description": formatted_names,
                    "color": 0xED4245
                }]
            }
            requests.post(WEBHOOK_TAKEN_URL, json=payload, timeout=5)
        except Exception:
            pass

def claim_username(target_username, token, password=""):
    """
    Bắn payload PATCH /users/@me với tốc độ mili-giây qua Pre-Warmed Session
    """
    # Nạp token sạch mới nhất từ file/env để đảm bảo luôn dùng token hợp lệ
    latest_token = get_discord_token()
    token_to_use = clean_token_str(latest_token if latest_token else token)

    # Đồng bộ header Authorization của claim_session
    claim_session.headers["Authorization"] = token_to_use

    url = "https://discord.com/api/v10/users/@me"
    payload = {"username": target_username}
    if password:
        payload["password"] = password.strip()

    safe_print(f"{C_CYAN}{C_BOLD}[{get_time()}] [AUTO-CLAIM] ⚡ Đang bắn yêu cầu đổi tên sang '{target_username}'...{C_RESET}")
    
    try:
        r = claim_session.patch(url, json=payload, proxies=get_proxies(), timeout=8)
    except Exception as e:
        safe_print(f"{C_YELLOW}[{get_time()}] [CLAIM] Thử gửi direct...{C_RESET}")
        try:
            r = claim_session.patch(url, json=payload, proxies=None, timeout=8)
        except Exception as e2:
            return False, None, f"Lỗi kết nối: {e2}"

    if r.status_code == 200:
        return True, r.json(), "Thành công"
    elif r.status_code == 401:
        safe_print(f"{C_YELLOW}[{get_time()}] [AUTO-CLAIM] ⚠️ Token hết hạn (401)! Đang tự động đăng nhập lại bằng Email/Password...{C_RESET}")
        ok, fresh_tok, _ = login_discord(DISCORD_EMAIL, DISCORD_PASSWORD)
        if ok and fresh_tok:
            safe_print(f"{C_GREEN}[{get_time()}] [AUTO-CLAIM] 🔄 Đã lấy Token mới, bắn lại lệnh claim ngay lập tức...{C_RESET}")
            claim_session.headers["Authorization"] = fresh_tok
            try:
                r2 = claim_session.patch(url, json=payload, proxies=get_proxies(), timeout=8)
            except Exception:
                try:
                    r2 = claim_session.patch(url, json=payload, proxies=None, timeout=8)
                except Exception as e2:
                    return False, None, f"Lỗi kết nối khi retry claim: {e2}"
            if r2.status_code == 200:
                return True, r2.json(), "Thành công (sau khi auto re-login)"
            elif r2.status_code == 401:
                return False, None, "HTTP 401: Token mới vẫn không có quyền claim."
            else:
                try:
                    return False, None, f"HTTP {r2.status_code}: {r2.json()}"
                except Exception:
                    return False, None, f"HTTP {r2.status_code}: {r2.text}"
        err_msg = "HTTP 401: Token Discord hết hạn và tự động đăng nhập lại thất bại."
        return False, None, err_msg
    else:
        try:
            err_json = r.json()
            if "captcha_key" in err_json or err_json.get("captcha_service") == "hcaptcha":
                err_msg = "Discord kích hoạt bảo mật hCaptcha. Chủ Nhân hãy đổi thủ công trên App ngay!"
            elif err_json.get("code") == 10020:
                err_msg = "Discord yêu cầu xác thực phiên / Captcha. Chủ Nhân hãy đổi thủ công trên App ngay!"
            else:
                err_msg = json.dumps(err_json, ensure_ascii=False)
        except Exception:
            err_msg = r.text
        return False, None, f"HTTP {r.status_code}: {err_msg}"

def check_user(username, slot):
    """
    Kiểm tra username qua session của slot được chỉ định với fail-fast timeout
    """
    with checked_lock:
        stats["checked"] += 1
        current_check_num = stats["checked"]

    url = "https://discord.com/api/v10/unique-username/username-attempt-unauthed"
    session = slot.session if (slot and slot.session) else create_worker_session(slot.proxy if slot else None)
    slot_tag = f"[Key #{slot.slot_id+1}]" if slot else ""

    try:
        r = session.post(
            url,
            headers=headers(),
            json={"username": username},
            timeout=(3.0, 5.0)  # Tối ưu fail-fast: 3s kết nối, 5s đọc phản hồi
        )

        if r.status_code == 200:
            data = r.json()
            if not data.get("taken"):
                with checked_lock:
                    stats["available"] += 1
                safe_print(f"{C_GREEN}{C_BOLD}[{get_time()}] [#{current_check_num}] [AVAILABLE] 🎯 Username '{username}' {slot_tag} KHẢ DỤNG! [{get_speed_str()}]{C_RESET}")
                return True, data
            else:
                with checked_lock:
                    stats["taken"] += 1
                safe_print(f"{C_WHITE}[{get_time()}] [#{current_check_num}] [TAKEN] '{username}' {slot_tag} -> ❌ Đã có người dùng [{get_speed_str()}]{C_RESET}")
                record_taken_name(username)
                queue_taken_name(username)
                return False, data

        elif r.status_code == 429:
            with checked_lock:
                stats["ratelimits"] += 1
            if slot:
                proxy_manager.mark_slot_429(slot)
            with checked_lock:
                if username not in retry_queue:
                    retry_queue.append(username)
            return None, None

        else:
            safe_print(f"{C_RED}[{get_time()}] [#{current_check_num}] [ERR {r.status_code}] '{username}' {slot_tag} -> {r.text[:80]}{C_RESET}")
            return None, None

    except requests.exceptions.Timeout:
        safe_print(f"{C_YELLOW}[{get_time()}] [TIMEOUT] '{username}' {slot_tag} -> Proxy phản hồi chậm quá 5s, đưa lại hàng đợi...{C_RESET}")
        with checked_lock:
            if username not in retry_queue:
                retry_queue.append(username)
        if slot:
            proxy_manager.mark_slot_error(slot, "Timeout > 5s")
        return None, None

    except (requests.exceptions.ConnectionError, requests.exceptions.ProxyError) as e:
        safe_print(f"{C_RED}[{get_time()}] [PROXY ERR] {slot_tag} gặp sự cố kết nối: {e}{C_RESET}")
        with checked_lock:
            if username not in retry_queue:
                retry_queue.append(username)
        if slot:
            proxy_manager.mark_slot_error(slot, "Connection/Proxy Error")
        return None, None

    except Exception as e:
        safe_print(f"{C_RED}[{get_time()}] [ERR] {slot_tag} Lỗi: {e}{C_RESET}")
        return None, None

    except Exception as e:
        safe_print(f"{C_RED}[{get_time()}] [ERR] Lỗi: {e}{C_RESET}")
        return None, None

RARE_LETTERS = list("qxzjvwkypbfg")
ALL_LETTERS = list(string.ascii_lowercase)
DIGITS = list(string.digits)
SPECIALS = ['.', '_']
AVOID_PATTERNS = {
    '00', '11', '22', '33', '44', '55', '66', '77', '88', '99',
    '69', '12', '23', '34', '45', '56', '67', '78', '89', '90', '01'
}

def gen_2c():
    """
    Sinh username 2 ký tự: Bắt buộc có ký tự đặc biệt _
    (Discord không cho phép dấu . ở đầu hoặc cuối, nên 2c dùng _).
    Ví dụ: a_, _x, 9_, _z, q_, _v...
    """
    c = random.choice(RARE_LETTERS) if random.random() < 0.75 else random.choice(ALL_LETTERS + DIGITS)
    return f"{c}_" if random.random() < 0.5 else f"_{c}"

def gen_3c():
    """
    Sinh username 3 ký tự: Bắt buộc có dấu . hoặc _
    - 65%: Dấu ở giữa c1.c2 hoặc c1_c2 (e.g. a.b, x_9, q.z, 8_k, j.2) - đẹp và giá trị nhất
    - 35%: Dấu _ ở đầu hoặc cuối (_ab, ab_, _9x, 9x_)
    """
    pool1 = RARE_LETTERS if random.random() < 0.75 else (ALL_LETTERS + DIGITS)
    pool2 = RARE_LETTERS if random.random() < 0.60 else (ALL_LETTERS + DIGITS)
    c1 = random.choice(pool1)
    c2 = random.choice(pool2)
    r = random.random()
    if r < 0.65:
        sep = random.choice(SPECIALS)
        return f"{c1}{sep}{c2}"
    elif r < 0.82:
        return f"_{c1}{c2}"
    else:
        return f"{c1}{c2}_"

def gen_4c():
    """
    Sinh username 4 ký tự tối ưu hóa tỷ lệ khả dụng (Available) theo yêu cầu của Chủ Nhân Azure:
    - Bắt buộc gồm chữ cái và số.
    - Linh hoạt 1 đến 3 số ở bất kỳ vị trí ngẫu nhiên nào.
    - Trọng số 75% ưu tiên phụ âm hiếm (q, x, z, j, v, w, y, k, p, b, f, g).
    - Bộ lọc thông minh loại bỏ các cụm số lặp (00, 11...), số tiến (12, 23...).
    """
    for _ in range(100):
        letter_pool = RARE_LETTERS if random.random() < 0.75 else ALL_LETTERS
        r = random.random()
        if r < 0.40:
            num_digits = 3
        elif r < 0.85:
            num_digits = 2
        else:
            num_digits = 1
        num_letters = 4 - num_digits
        chosen_letters = [random.choice(letter_pool) for _ in range(num_letters)]
        chosen_digits = [random.choice(DIGITS) for _ in range(num_digits)]
        combined = chosen_letters + chosen_digits
        random.shuffle(combined)
        candidate = ''.join(combined)
        if any(bad in candidate for bad in AVOID_PATTERNS):
            continue
        return candidate
    return random.choice(RARE_LETTERS) + str(random.randint(100, 999))

def gen_name():
    """
    Sinh ngẫu nhiên giữa 2c, 3c và 4c theo tỷ lệ:
    - 2c (20%): Bắt buộc chứa _ (e.g. _a, a_, _z)
    - 3c (45%): Bắt buộc chứa . hoặc _ (e.g. a.b, x_9, q.z)
    - 4c (35%): Random chữ + số hiếm như 4c gốc
    """
    p = random.random()
    if p < 0.20:
        return gen_2c()
    elif p < 0.65:
        return gen_3c()
    else:
        return gen_4c()

TAKEN_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "taken_names.txt")

def load_taken_names():
    """
    Đọc toàn bộ các username đã bị Taken từ file taken_names.txt để bỏ qua vĩnh viễn
    """
    if os.path.exists(TAKEN_FILE):
        try:
            with open(TAKEN_FILE, "r", encoding="utf-8") as f:
                names = {line.strip().lower() for line in f if line.strip()}
            return names
        except Exception as e:
            safe_print(f"{C_YELLOW}[!] Không thể đọc file taken_names.txt: {e}{C_RESET}")
    return set()

def record_taken_name(name):
    """
    Ghi nhận username bị Taken vào bộ nhớ đệm và lưu nối tiếp vào file taken_names.txt
    """
    name = name.strip().lower()
    with checked_lock:
        checked_names.add(name)
    try:
        with open(TAKEN_FILE, "a", encoding="utf-8") as f:
            f.write(name + "\n")
    except Exception:
        pass

TOKEN_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".discord_token")

def get_discord_token():
    global DISCORD_TOKEN
    # 1. Ưu tiên đọc biến môi trường DISCORD_TOKEN
    env_token = clean_token_str(os.environ.get("DISCORD_TOKEN", ""))
    if env_token:
        DISCORD_TOKEN = env_token
        return DISCORD_TOKEN

    # 2. Ưu tiên đọc file .discord_token để khi cập nhật file không bị dính token cũ
    if os.path.exists(TOKEN_FILE):
        try:
            with open(TOKEN_FILE, "r", encoding="utf-8") as f:
                saved = clean_token_str(f.read())
                if saved:
                    DISCORD_TOKEN = saved
                    return DISCORD_TOKEN
        except Exception:
            pass

    # 3. Fallback biến DISCORD_TOKEN hardcode trong code
    clean_code_token = clean_token_str(DISCORD_TOKEN)
    if clean_code_token:
        return clean_code_token

    return ""

def create_worker_session(proxy_str):
    """
    Tạo session mới kết nối trực tiếp qua proxy được chỉ định
    """
    s = requests.Session()
    adapter = requests.adapters.HTTPAdapter(pool_connections=10, pool_maxsize=10)
    s.mount('https://', adapter)
    s.mount('http://', adapter)
    if proxy_str:
        p_url = f"http://{proxy_str}" if not proxy_str.startswith("http") else proxy_str
        s.proxies = {'http': p_url, 'https': p_url}
    return s

def worker_loop(worker_id):
    """
    Luồng quét độc lập: Lấy slot từ DualKeyProxyManager (1 và 2 thay nhau liên tục),
    điều tiết đúng nhịp 3 names/s.
    """
    while not stop_flag.is_set():
        slot = proxy_manager.get_slot()
        if not slot or not slot.proxy:
            time.sleep(0.3)
            continue

        name = None
        with checked_lock:
            while retry_queue:
                cand = retry_queue.pop(0)
                if cand not in checked_names:
                    name = cand
                    break

            if not name:
                for _ in range(500):
                    cand = gen_name()
                    if cand not in checked_names:
                        name = cand
                        checked_names.add(cand)
                        break

        if not name:
            while not stop_flag.is_set():
                cand = gen_name()
                with checked_lock:
                    if cand not in checked_names:
                        name = cand
                        checked_names.add(cand)
                        break

        # Điều tiết nhịp quét chính xác 3 names / giây trên toàn hệ thống (Chủ Nhân Azure chỉ định)
        rate_limiter.acquire()
        avail, _ = check_user(name, slot)
        
        if avail is True:
            safe_print(f"\n{C_MAGENTA}{C_BOLD}{'='*50}")
            safe_print(f"🎯 [LUỒNG #{worker_id}] TÌM THẤY TÊN KHẢ DỤNG: '{name}'! BẮN ALERT PING @everyone...")
            safe_print(f"{'='*50}{C_RESET}\n")
            
            with checked_lock:
                stats["available"] += 1
                stats["sniped"] += 1

            # Ghi nhận username vào file sniped_names.txt
            record_sniped_name(name)

            # 1. BẮN NGAY LẬP TỨC WEBHOOK ALERT PING @everyone ĐỂ CHỦ NHÂN MỞ APP ĐỔI LIỀN!
            alert_msg_id = send_webhook_embed(name, "AVAILABLE_ALERT")

            # 2. KHỞI CHẠY LUỒNG NGẦM WATCHDOG THEO DÕI LIVE & TỰ ĐỘNG CẬP NHẬT EMBED KHI BỊ CLAIM!
            if alert_msg_id:
                threading.Thread(
                    target=watch_and_update_available_alert,
                    args=(name, alert_msg_id, time.time()),
                    daemon=True
                ).start()

            # Tiếp tục chu kỳ quét liên tục không dừng luồng
            time.sleep(0.5)
        elif avail is False:
            pass
        else:
            time.sleep(0.3)

def token_watchdog_worker():
    """
    Luồng ngầm giám sát token Discord liên tục.
    Nếu Chủ Nhân log acc qua client khác khiến token cũ die (401),
    worker sẽ tự động:
    1. Đăng nhập lại bằng Email & Mật khẩu lấy token mới.
    2. Cập nhật DISCORD_TOKEN và session cục bộ.
    3. Tự động upload token mới lên host Pterodactyl (control.heavencloud.in).
    4. Gửi tín hiệu restart server host nếu bật AUTO_RESTART_HOST.
    """
    time.sleep(30)  # Chờ 30s sau khi khởi động xong mới bắt đầu chu kỳ giám sát
    while not stop_flag.is_set():
        # Kiểm tra mỗi 90 giây
        for _ in range(90):
            if stop_flag.is_set():
                return
            time.sleep(1)

        latest_token = get_discord_token()
        valid, user_data = validate_token(latest_token)

        if not valid:
            safe_print(f"\n{C_YELLOW}{C_BOLD}[{get_time()}] [WATCHDOG] ⚠️ PHÁT HIỆN TOKEN ĐÃ HẾT HẠN / DIE (Do đăng nhập client khác)!{C_RESET}")
            safe_print(f"{C_YELLOW}[{get_time()}] [WATCHDOG] 🔄 Tiến hành tự động đăng nhập lại bằng Email/Password & đồng bộ Host...{C_RESET}")
            
            logged_in, fresh_tok, auth_data = login_discord(DISCORD_EMAIL, DISCORD_PASSWORD)
            if logged_in and fresh_tok:
                safe_print(f"{C_GREEN}{C_BOLD}[{get_time()}] [WATCHDOG] ✅ ĐÃ CẤP LẠI TOKEN MỚI VÀ ĐỒNG BỘ HOST XONG! Tiếp tục vận hành.{C_RESET}\n")
            else:
                safe_print(f"{C_RED}[{get_time()}] [WATCHDOG] ❌ Đăng nhập lại thất bại: {auth_data}{C_RESET}\n")


def stats_reporter_worker():
    pause_file = os.path.join(BASE_DIR, ".sniper_paused")
    while not stop_flag.is_set():
        time.sleep(1.0)
        try:
            with checked_lock:
                c = stats.get("checked", 0)
                t = stats.get("taken", 0)
                s = stats.get("sniped", 0)
                a = stats.get("available", 0)
            with proxy_lock:
                p = current_proxy
            el = max(1.0, time.time() - start_time)
            cpm = (c / el) * 60.0
            cps = c / el
            data = {
                "checked": c,
                "taken": t,
                "sniped": s,
                "available": a,
                "proxy": p or "Direct",
                "speed_cpm": round(cpm, 1),
                "speed_cps": round(cps, 2),
                "paused": os.path.exists(pause_file),
                "uptime_sec": int(el),
                "timestamp": time.time()
            }
            tmp_p = os.path.join(BASE_DIR, ".sniper_stats.json.tmp")
            dst_p = os.path.join(BASE_DIR, ".sniper_stats.json")
            with open(tmp_p, "w", encoding="utf-8") as f:
                json.dump(data, f)
            os.replace(tmp_p, dst_p)
        except Exception:
            pass

def gateway_keeper_worker():
    """
    Luồng ngầm duy trì kết nối WebSocket Gateway tới Discord.
    Giúp tài khoản luôn ở trạng thái Online (Live) và có Gateway Session hợp lệ,
    loại bỏ hoàn toàn mã lỗi 10020 (Unknown Session) của Discord.
    """
    try:
        import websockets
        import asyncio
    except Exception:
        return

    async def _gateway_loop():
        while not stop_flag.is_set():
            tok = get_discord_token()
            if not tok:
                await asyncio.sleep(5)
                continue
            try:
                uri = "wss://gateway.discord.gg/?v=10&encoding=json"
                async with websockets.connect(uri, ping_interval=None) as ws:
                    hello = await ws.recv()
                    hello_data = json.loads(hello)
                    interval = hello_data["d"]["heartbeat_interval"] / 1000.0

                    identify = {
                        "op": 2,
                        "d": {
                            "token": tok,
                            "capabilities": 30717,
                            "properties": {
                                "os": "Windows",
                                "browser": "Chrome",
                                "device": "",
                                "system_locale": "vi-VN",
                                "browser_user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
                                "browser_version": "128.0.0.0",
                                "os_version": "10",
                                "release_channel": "stable",
                                "client_build_number": 324128
                            },
                            "presence": {"status": "online", "since": 0, "activities": [], "afk": False},
                            "compress": False,
                            "client_state": {"guild_versions": {}, "highest_last_message_id": "0", "read_state_version": 0, "user_guild_settings_version": -1, "user_settings_version": -1}
                        }
                    }
                    await ws.send(json.dumps(identify))

                    ready = await ws.recv()
                    ready_data = json.loads(ready)
                    if ready_data.get("t") == "READY":
                        session_id = ready_data["d"]["session_id"]
                        safe_print(f"{C_GREEN}[*] [GATEWAY] 🟢 Đã kết nối Discord Gateway! Session ID: {session_id[:12]}... (Tài khoản Live Online){C_RESET}")
                        claim_session.headers["X-Session-Id"] = session_id

                    # Vòng lặp gửi heartbeat định kỳ
                    while not stop_flag.is_set():
                        await asyncio.sleep(interval)
                        await ws.send(json.dumps({"op": 1, "d": None}))
            except Exception:
                await asyncio.sleep(5)

    def _run():
        try:
            asyncio.run(_gateway_loop())
        except Exception:
            pass

    t = threading.Thread(target=_run, daemon=True)
    t.start()

def main():
    global DISCORD_TOKEN, DISCORD_PASSWORD, start_time

    start_time = time.time()
    fetch_current_nestproxy()
    keys_info = fetch_key_details()
    loaded_taken = load_taken_names()
    with checked_lock:
        checked_names.update(loaded_taken)

    # Khởi động worker duy trì kết nối Gateway Live để diệt lỗi 10020
    gateway_keeper_worker()

    # Khởi động worker gom batch webhook taken chống spam thread
    if ENABLE_TAKEN_WEBHOOK and WEBHOOK_TAKEN_URL:
        t_taken = threading.Thread(target=taken_webhook_worker, daemon=True)
        t_taken.start()

    # Khởi động watchdog thống kê
    t_stats = threading.Thread(target=stats_reporter_worker, daemon=True)
    t_stats.start()
    t_sniped_live = threading.Thread(target=sniped_live_check_worker, daemon=True)
    t_sniped_live.start()

    print(f"\n{C_CYAN}{C_BOLD}{'='*60}")
    print("      ⚡ AZURE ULTRA HIGH-SPEED DISCORD NAME SNIPER")
    print(f"{'='*60}{C_RESET}")
    print(f"{C_WHITE}🛡️  Proxy Hiện Tại  : {C_GREEN}{current_proxy or 'Không dùng'}{C_RESET}")
    print(f"{C_WHITE}📡 Webhook Báo Trúng: {C_GREEN}{'Đã kích hoạt' if WEBHOOK_URL else 'Chưa cài'}{C_RESET}")
    print(f"{C_WHITE}📡 Webhook Báo Taken: {C_GREEN}{'Đã kích hoạt (Batch 15-20 names)' if (WEBHOOK_TAKEN_URL and ENABLE_TAKEN_WEBHOOK) else 'Tắt'}{C_RESET}")
    print(f"{C_WHITE}📁 Bỏ Qua Taken     : {C_GREEN}{len(loaded_taken)} usernames (Lưu vĩnh viễn, không check lại){C_RESET}")
    print(f"{C_WHITE}🔑 Cụm Proxy Keys   : {C_GREEN}{len(PROXY_KEYS)} Key Luân Phiên (1 và 2 thay nhau liên tục){C_RESET}")
    for idx, slot in enumerate(proxy_manager.slots):
        k = slot.key
        info_str = f"IP: {slot.proxy or 'Chưa nạp'}"
        for ki in keys_info:
            if ki.get('proxyKey') == k:
                k_type = ki.get('keyType', 'NORMAL')
                k_exp = ki.get('expiredAt', '')[:16].replace('T', ' ')
                k_status = '✅ Active' if ki.get('isActive') else '❌ Hết Hạn'
                info_str += f" | Gói {k_type} | Hạn: {k_exp} | {k_status}"
                break
        print(f"{C_WHITE}   └─ Key #{idx+1} ({k[:15]}...): {C_CYAN}{info_str} 🟢 [THAY NHAU]{C_RESET}")
    if PROVINCE_ID:
        print(f"{C_WHITE}📍 Vùng Định Tuyến : {C_GREEN}Tỉnh ID {PROVINCE_ID}{C_RESET}")
    print(f"{C_WHITE}🚀 Chế Độ Quét     : {C_GREEN}Đơn luồng (Không chạy 2 cái cùng lúc){C_RESET}")
    print(f"{C_WHITE}⏱️  Nhịp Kiểm Tra   : {C_GREEN}{CHECK_DELAY_MIN}s - {CHECK_DELAY_MAX}s (~0.5s / username) [Tăng tốc gấp 3 lần]{C_RESET}")
    print(f"{C_WHITE}📏 Định Dạng Tên    : {C_GREEN}4 ký tự Chữ + Số (Trọng số ký tự hiếm & Lọc số trùng){C_RESET}")
    print(f"{C_WHITE}🎯 Chế Độ Hoạt Động : {C_GREEN}Alert Webhook Ping @everyone & Live Watchdog Auto-Update (Bỏ Auto-Claim){C_RESET}")
    print(f"{C_GREEN}[*] Sẵn sàng khởi chạy săn username khả dụng...{C_RESET}")

    print(f"{C_CYAN}{'='*60}\n{C_RESET}")
    print(f"{C_GREEN}[*] Bắt đầu quét nhịp ~0.5s/username (Đơn luồng, siêu tốc & an toàn)... (Nhấn Ctrl+C để dừng){C_RESET}\n")

    threads = []
    for i in range(1, THREAD_COUNT + 1):
        t = threading.Thread(target=worker_loop, args=(i,), daemon=True)
        t.start()
        threads.append(t)

    try:
        while not stop_flag.is_set():
            time.sleep(0.5)
        for t in threads:
            t.join(timeout=1.0)
    except KeyboardInterrupt:
        stop_flag.set()
        print(f"\n\n{C_YELLOW}[!] Đã nhận tín hiệu dừng từ Chủ Nhân Azure.{C_RESET}")
    
    elapsed = max(1.0, time.time() - start_time)
    cpm = (stats['checked'] / elapsed) * 60
    cps = stats['checked'] / elapsed
    print(f"{C_WHITE}📊 Thống kê: Checked: {stats['checked']} | Taken: {stats['taken']} | Available: {stats['available']} | Sniped: {stats['sniped']} | Tốc độ TB: {cpm:.1f} names/phút ({cps:.2f}/s){C_RESET}")

if __name__ == "__main__":
    main()