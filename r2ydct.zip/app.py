# -*- coding: utf-8 -*-
import os
import sys
import runpy
import subprocess
import threading
import time
import socket
import http.server
import mimetypes
import json
import urllib.parse
import urllib.request

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE_DIR)

for p in [
    os.path.join(BASE_DIR, ".local", "lib", "python3.13", "site-packages"),
    os.path.join(BASE_DIR, ".local", "lib", "site-packages"),
    BASE_DIR
]:
    if os.path.exists(p) and p not in sys.path:
        sys.path.insert(0, p)

log_lines = []
log_lock = threading.RLock()

class DualOutput:
    def __init__(self, original):
        self.original = original

    def write(self, s):
        try:
            self.original.write(s)
        except Exception:
            pass
        if s:
            try:
                with log_lock:
                    for chunk in s.splitlines(keepends=True):
                        clean = chunk.rstrip("\r\n")
                        if clean:
                            log_lines.append(clean)
                            if len(log_lines) > 2000:
                                del log_lines[:500]
            except Exception:
                pass

    def flush(self):
        try:
            self.original.flush()
        except Exception:
            pass

sys.stdout = DualOutput(sys.stdout)
sys.stderr = sys.stdout

print("[Azure Wrapper] Khởi động Discord Name Sniper, Cloudflare Tunnel & Azure Dashboard...")

WEB_DIR = os.path.join(BASE_DIR, "web")
os.makedirs(WEB_DIR, exist_ok=True)

HTML_CACHE = {}

def get_cached_html(file_path):
    mtime = os.path.getmtime(file_path) if os.path.exists(file_path) else 0
    cached = HTML_CACHE.get(file_path)
    if cached and cached[0] == mtime:
        return cached[1]
    if os.path.exists(file_path):
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()
        HTML_CACHE[file_path] = (mtime, content)
        return content
    return None

class AzureDashboardHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.0"
    close_connection = True
    timeout = 6

    def address_string(self):
        # Triệt tiêu hoàn toàn reverse DNS lookup (socket.getfqdn) gây treo 3-5s
        return "127.0.0.1"

    def log_message(self, format, *args):
        pass

    def do_GET(self):
        self._t0 = time.time()
        try:
            parsed = urllib.parse.urlparse(self.path)
            path = parsed.path.strip("/")
            qs = urllib.parse.parse_qs(parsed.query)

            # 1. API: Consolidated Sync (Stats + Logs trong 1 request duy nhất)
            if path == "api/sync":
                offset = 0
                if "offset" in qs:
                    try:
                        offset = int(qs["offset"][0])
                    except Exception:
                        offset = 0

                stats_file = os.path.join(BASE_DIR, ".sniper_stats.json")
                stats_data = {}
                if os.path.exists(stats_file):
                    try:
                        with open(stats_file, "r", encoding="utf-8") as f:
                            stats_data = json.load(f)
                    except Exception:
                        pass
                
                if not stats_data:
                    taken_count = 0
                    taken_f = os.path.join(BASE_DIR, "taken_names.txt")
                    if os.path.exists(taken_f):
                        try:
                            with open(taken_f, "r", encoding="utf-8", errors="ignore") as f:
                                taken_count = sum(1 for _ in f)
                        except Exception:
                            taken_count = 0
                    stats_data = {
                        "checked": taken_count,
                        "taken": taken_count,
                        "sniped": 0,
                        "available": 0,
                        "proxy": "Đang nạp...",
                        "speed_cpm": 120.0,
                        "speed_cps": 2.0,
                        "paused": os.path.exists(os.path.join(BASE_DIR, ".sniper_paused")),
                        "uptime_sec": 0
                    }

                with log_lock:
                    total = len(log_lines)
                    if offset == 0:
                        slice_logs = log_lines[-50:] if total > 50 else list(log_lines)
                    else:
                        slice_logs = log_lines[offset:offset + 50] if offset < total else []

                self.send_json({
                    "stats": stats_data,
                    "logs": slice_logs,
                    "total": total
                })
                return

            # 2. API: Stream Logs (Legacy)
            if path == "api/logs":
                offset = 0
                if "offset" in qs:
                    try:
                        offset = int(qs["offset"][0])
                    except Exception:
                        offset = 0
                with log_lock:
                    total = len(log_lines)
                    if offset == 0 and total > 60:
                        slice_logs = log_lines[-60:]
                    else:
                        slice_logs = log_lines[offset:offset + 60] if offset < total else []
                self.send_json({"logs": slice_logs, "total": total})
                return

            # 3. API: Live Stats (Legacy)
            if path in ("api/stats", "api/status", "status"):
                stats_file = os.path.join(BASE_DIR, ".sniper_stats.json")
                stats_data = {}
                if os.path.exists(stats_file):
                    try:
                        with open(stats_file, "r", encoding="utf-8") as f:
                            stats_data = json.load(f)
                    except Exception:
                        pass
                if not stats_data:
                    taken_count = 0
                    taken_f = os.path.join(BASE_DIR, "taken_names.txt")
                    if os.path.exists(taken_f):
                        try:
                            with open(taken_f, "r", encoding="utf-8", errors="ignore") as f:
                                taken_count = sum(1 for _ in f)
                        except Exception:
                            taken_count = 0
                    stats_data = {
                        "checked": taken_count,
                        "taken": taken_count,
                        "sniped": 0,
                        "available": 0,
                        "proxy": "Đang nạp...",
                        "speed_cpm": 120.0,
                        "speed_cps": 2.0,
                        "paused": os.path.exists(os.path.join(BASE_DIR, ".sniper_paused")),
                        "uptime_sec": 0
                    }
                self.send_json(stats_data)
                return

            # 4. Downloads
            if path == "api/download/taken":
                self.send_download_file(os.path.join(BASE_DIR, "taken_names.txt"), "taken_names.txt")
                return
            if path == "api/download/sniped":
                self.send_download_file(os.path.join(BASE_DIR, "sniped_names.txt"), "sniped_names.txt")
                return
            if path == "api/download/cflog":
                self.send_download_file(os.path.join(BASE_DIR, "cloudflared.log"), "cloudflared.log")
                return

            # 5. Showcase (Kiếm Cơm)
            if path == "showcase":
                showcase_p = os.path.join(WEB_DIR, "showcase.html")
                if not os.path.exists(showcase_p):
                    showcase_p = os.path.join(BASE_DIR, "showcase.html")
                content = get_cached_html(showcase_p)
                if content:
                    base_u = f"{self.headers.get('X-Forwarded-Proto', 'https')}://{self.headers.get('Host', 'kemhosting.site')}"
                    content = content.replace("{{BASE_URL}}", base_u)
                    self.send_html(content)
                    return

            # 6. Static files
            clean_rel = path.split("?")[0].lstrip("/")
            if clean_rel:
                file_path = os.path.join(WEB_DIR, clean_rel)
                if not os.path.exists(file_path):
                    file_path = os.path.join(BASE_DIR, clean_rel)
                if os.path.isfile(file_path):
                    self.send_static(file_path)
                    return

            # Default: Serve Dashboard Home (index.html)
            dash_p = os.path.join(WEB_DIR, "index.html")
            content = get_cached_html(dash_p)
            if content:
                self.send_html(content)
                return

            self.send_response(404)
            self.send_header("Connection", "close")
            self.end_headers()
            self.wfile.write(b"404 Not Found")
            self.wfile.flush()
            self.close_connection = True
        except Exception as e:
            try:
                self.send_response(500)
                self.send_header("Connection", "close")
                self.end_headers()
                self.wfile.write(f"500 Internal Error: {e}".encode("utf-8"))
                self.wfile.flush()
                self.close_connection = True
            except Exception:
                pass

    def do_POST(self):
        self._t0 = time.time()
        try:
            parsed = urllib.parse.urlparse(self.path)
            path = parsed.path.strip("/")
            qs = urllib.parse.parse_qs(parsed.query)

            if path == "api/action/pause":
                with open(os.path.join(BASE_DIR, ".sniper_paused"), "w") as f:
                    f.write("1")
                print("[DASHBOARD] ⏸️ Nhận lệnh TẠM DỪNG quét Discord Sniper từ Web UI!")
                self.send_json({"ok": True, "paused": True})
                return

            if path == "api/action/resume":
                p_file = os.path.join(BASE_DIR, ".sniper_paused")
                if os.path.exists(p_file):
                    try:
                        os.remove(p_file)
                    except Exception:
                        pass
                print("[DASHBOARD] ▶️ Nhận lệnh TIẾP TỤC quét Discord Sniper từ Web UI!")
                self.send_json({"ok": True, "paused": False})
                return

            if path == "api/action/rotate_proxy":
                with open(os.path.join(BASE_DIR, ".trigger_rotate_proxy"), "w") as f:
                    f.write("1")
                print("[DASHBOARD] 🔄 Nhận lệnh XOAY PROXY từ Web UI!")
                self.send_json({"ok": True, "msg": "Triggered proxy rotation"})
                return

            if path == "api/action/check":
                name = qs.get("name", [""])[0].strip().lower()
                if not name:
                    self.send_json({"error": "Thiếu username"}, status=400)
                    return

                try:
                    url = "https://discord.com/api/v10/unique-username/username-attempt-unauthed"
                    req = urllib.request.Request(
                        url,
                        data=json.dumps({"username": name}).encode("utf-8"),
                        headers={
                            "Content-Type": "application/json",
                            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
                        }
                    )
                    stats_file = os.path.join(BASE_DIR, ".sniper_stats.json")
                    curr_proxy = None
                    if os.path.exists(stats_file):
                        try:
                            with open(stats_file, "r", encoding="utf-8") as f:
                                curr_proxy = json.load(f).get("proxy")
                        except Exception:
                            pass

                    handlers = []
                    if curr_proxy and curr_proxy != "Direct":
                        handlers.append(urllib.request.ProxyHandler({"http": f"http://{curr_proxy}", "https": f"http://{curr_proxy}"}))
                    opener = urllib.request.build_opener(*handlers)

                    with opener.open(req, timeout=3.5) as resp:
                        data = json.loads(resp.read().decode("utf-8"))
                        taken = data.get("taken", True)
                        self.send_json({"name": name, "taken": taken, "status": resp.status})
                        return
                except Exception as err:
                    err_str = str(err)
                    if "HTTP Error 400" in err_str:
                        self.send_json({"name": name, "taken": True, "status": 400})
                    elif "HTTP Error 429" in err_str:
                        self.send_json({"error": "Rate limited (429)"}, status=429)
                    else:
                        self.send_json({"error": str(err)}, status=500)
                    return

            self.send_json({"error": "Not Found"}, status=404)
        except Exception as e:
            self.send_json({"error": str(e)}, status=500)

    def send_json(self, data, status=200):
        body = json.dumps(data).encode("utf-8")
        t_elapsed = round((time.time() - getattr(self, "_t0", time.time())) * 1000, 2)
        self.send_response(status)
        self.send_header("X-App-Time-Ms", str(t_elapsed))
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
        self.end_headers()
        self.wfile.write(body)
        self.wfile.flush()
        self.close_connection = True

    def send_html(self, content):
        body = content.encode("utf-8")
        t_elapsed = round((time.time() - getattr(self, "_t0", time.time())) * 1000, 2)
        self.send_response(200)
        self.send_header("X-App-Time-Ms", str(t_elapsed))
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(body)
        self.wfile.flush()
        self.close_connection = True

    def send_static(self, f_path):
        mime, _ = mimetypes.guess_type(f_path)
        with open(f_path, "rb") as f:
            b = f.read()
        self.send_response(200)
        self.send_header("Content-Type", mime or "application/octet-stream")
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Connection", "close")
        self.send_header("Cache-Control", "public, max-age=86400")
        self.end_headers()
        self.wfile.write(b)
        self.wfile.flush()
        self.close_connection = True

    def send_download_file(self, f_path, filename):
        if not os.path.exists(f_path):
            self.send_response(404)
            self.send_header("Connection", "close")
            self.end_headers()
            self.wfile.write(b"File not found")
            self.wfile.flush()
            self.close_connection = True
            return
        with open(f_path, "rb") as f:
            b = f.read()
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(b)
        self.wfile.flush()
        self.close_connection = True

def launch_web_server():
    server = None
    try:
        class DualStackServer(http.server.ThreadingHTTPServer):
            address_family = socket.AF_INET6
            daemon_threads = True
            allow_reuse_address = True
            def server_bind(self):
                try:
                    self.socket.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
                except Exception:
                    pass
                super().server_bind()

        server = DualStackServer(("::", 8080), AzureDashboardHandler)
        print("[Kem Web] 🚀 Web Server đã mở tại [::]:8080 (Dual-Stack IPv4+IPv6)!")
    except Exception as err:
        print(f"[Kem Web] ⚠️ IPv6 dual-stack không khả dụng ({err}), chuyển sang IPv4...")
        try:
            class IPv4Server(http.server.ThreadingHTTPServer):
                address_family = socket.AF_INET
                daemon_threads = True
                allow_reuse_address = True

            server = IPv4Server(("0.0.0.0", 8080), AzureDashboardHandler)
            print("[Kem Web] 🚀 Web Server đã mở tại 0.0.0.0:8080 (IPv4)!")
        except Exception as err2:
            print(f"[Kem Web] ❌ Không thể mở Web Server: {err2}")
            return

    if server:
        server.serve_forever()

t_web = threading.Thread(target=launch_web_server, daemon=True)
t_web.start()

def local_self_test():
    time.sleep(2)
    try:
        t0 = time.time()
        req = urllib.request.Request("http://127.0.0.1:8080/")
        with urllib.request.urlopen(req, timeout=3) as resp:
            dur = (time.time() - t0) * 1000
            data = resp.read()
            with open("web_test.log", "w", encoding="utf-8") as f:
                f.write(f"OK: status={resp.status}, dur={dur:.2f}ms, bytes={len(data)}\n")
    except Exception as e:
        with open("web_test.log", "w", encoding="utf-8") as f:
            f.write(f"FAIL: {e}\n")

threading.Thread(target=local_self_test, daemon=True).start()

def launch_cloudflared():
    cf_token_file = os.path.join(BASE_DIR, ".cf_token")
    if not os.path.exists(cf_token_file):
        return
    with open(cf_token_file, "r", encoding="utf-8") as f:
        token = f.read().strip()
    if not token:
        return

    cf_bin = os.path.join(BASE_DIR, "cloudflared")
    try:
        os.chmod(cf_bin, 0o755)
    except Exception:
        pass

    log_file = os.path.join(BASE_DIR, "cloudflared.log")
    cmd = [
        cf_bin,
        "--edge-ip-version", "4",
        "tunnel",
        "run",
        "--dns-resolver-addrs", "1.1.1.1:53",
        "--protocol", "http2",
        "--token", token
    ]

    while True:
        try:
            if os.path.exists(log_file) and os.path.getsize(log_file) > 500000:
                try:
                    with open(log_file, "w", encoding="utf-8") as f_trunc:
                        f_trunc.write("[Cloudflared] Log rotated.\n")
                except Exception:
                    pass

            with open(log_file, "a", encoding="utf-8", buffering=1) as f_log:
                proc = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    bufsize=1
                )
                print(f"[Cloudflared] 🚀 Tunnel PID: {proc.pid}")
                for line in proc.stdout:
                    f_log.write(line)
                    clean = line.strip()
                    if "Registered tunnel connection" in clean:
                        print(f"[Cloudflared] {clean}")
                proc.wait()
        except Exception as err:
            print(f"[Cloudflared] ⚠️ Lỗi tunnel: {err}")
        time.sleep(2)

t_cf = threading.Thread(target=launch_cloudflared, daemon=True)
t_cf.start()

time.sleep(2)

try:
    runpy.run_path(os.path.join(BASE_DIR, "namesn.py"), run_name="__main__")
except Exception as e:
    import traceback
    print("[Azure Wrapper Fatal] Lỗi khi chạy namesn.py:", e)
    traceback.print_exc()
    sys.exit(1)
